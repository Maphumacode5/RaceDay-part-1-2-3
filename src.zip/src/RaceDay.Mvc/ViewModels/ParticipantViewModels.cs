using RaceDay.Mvc.Models.Api;

namespace RaceDay.Mvc.ViewModels;

public class MyEnrolmentsViewModel
{
    public List<EnrolmentDto> Enrolments { get; set; } = new();

    public string? LoadError { get; set; }
}

public class MyResultsViewModel
{
    public List<ResultDto> Results { get; set; } = new();

    public string? LoadError { get; set; }

    public int RacesCompleted => Results.Count;

    public ResultDto? BestFinish =>
        Results.Where(r => r.FinishPosition.HasValue)
               .OrderBy(r => r.FinishPosition)
               .FirstOrDefault();
}
