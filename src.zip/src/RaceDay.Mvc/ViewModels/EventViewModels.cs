using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using RaceDay.Mvc.Models.Api;

namespace RaceDay.Mvc.ViewModels;

/// <summary>Search, type, distance and sort options for the event browser (bound from the query string).</summary>
public class EventFilterViewModel
{
    public string? Search { get; set; }

    public string? Type { get; set; }

    public string? Distance { get; set; }

    public string? Sort { get; set; }

    public bool IncludePast { get; set; }

    public bool IsActive =>
        !string.IsNullOrWhiteSpace(Search)
        || (!string.IsNullOrWhiteSpace(Type) && Type != "All")
        || !string.IsNullOrWhiteSpace(Distance)
        || IncludePast;
}

public class EventListViewModel
{
    public EventFilterViewModel Filter { get; set; } = new();

    public List<EventDto> Events { get; set; } = new();

    /// <summary>Number of events before filtering, so the page can say "3 of 12 events".</summary>
    public int TotalCount { get; set; }

    /// <summary>Set when the API could not be reached, so the page can explain instead of crashing.</summary>
    public string? LoadError { get; set; }

    /// <summary>The controller/action that the filter form submits to.</summary>
    public string FormController { get; set; } = "Events";

    public string FormAction { get; set; } = "Index";

    public string Heading { get; set; } = "Upcoming events";
}

public class EventDetailViewModel
{
    public EventDetailDto Event { get; set; } = null!;

    public List<CategoryDto> Categories { get; set; } = new();

    public bool IsParticipant { get; set; }

    public bool IsOwner { get; set; }

    /// <summary>The Participant's existing enrolment for this event, if any.</summary>
    public EnrolmentDto? ExistingEnrolment { get; set; }

    public bool HasEnded => Event.EventDate < DateTime.Now;
}

public class EventFormViewModel
{
    public int EventId { get; set; }

    [Required(ErrorMessage = "Enter a name for the event.")]
    [StringLength(150, ErrorMessage = "The name can be at most 150 characters.")]
    [Display(Name = "Event name")]
    public string Name { get; set; } = "";

    [StringLength(1000, ErrorMessage = "The description can be at most 1000 characters.")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Choose the date and start time.")]
    [Display(Name = "Date and start time")]
    public DateTime? EventDate { get; set; }

    [Required(ErrorMessage = "Enter the location.")]
    [StringLength(200, ErrorMessage = "The location can be at most 200 characters.")]
    public string Location { get; set; } = "";

    [Range(0.01, 999.99, ErrorMessage = "Enter a distance between 0.01 and 999.99 km.")]
    [Display(Name = "Distance (km)")]
    public decimal DistanceKm { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Choose an event type.")]
    [Display(Name = "Event type")]
    public int EventTypeId { get; set; }

    /// <summary>Optional banner image chosen by the Organiser.</summary>
    [Display(Name = "Banner image")]
    public IFormFile? BannerImage { get; set; }

    public string? ExistingBannerUrl { get; set; }

    [BindNever]
    [ValidateNever]
    public List<EventTypeDto> EventTypes { get; set; } = new();
}

public class CategoryFormViewModel
{
    public int CategoryId { get; set; }

    public int EventId { get; set; }

    [Required(ErrorMessage = "Enter a category name, for example Under 20 or 21km.")]
    [StringLength(100, ErrorMessage = "The name can be at most 100 characters.")]
    public string Name { get; set; } = "";

    [StringLength(300, ErrorMessage = "The description can be at most 300 characters.")]
    public string? Description { get; set; }
}
