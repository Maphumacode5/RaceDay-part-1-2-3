using RaceDay.Mvc.Models.Api;

namespace RaceDay.Mvc.ViewModels;

public class DashboardEventRow
{
    public EventDto Event { get; set; } = null!;

    public int TotalEnrolments { get; set; }

    public int PendingEnrolments { get; set; }

    public int ConfirmedEnrolments { get; set; }

    public bool IsUpcoming => Event.EventDate >= DateTime.Now;

    public int DaysUntil => (int)Math.Ceiling((Event.EventDate - DateTime.Now).TotalDays);
}

public class OrganiserDashboardViewModel
{
    public List<DashboardEventRow> Rows { get; set; } = new();

    public string? LoadError { get; set; }

    public int TotalEvents => Rows.Count;

    public int UpcomingEvents => Rows.Count(r => r.IsUpcoming);

    public int TotalEnrolments => Rows.Sum(r => r.TotalEnrolments);

    public int PendingEnrolments => Rows.Sum(r => r.PendingEnrolments);

    public IEnumerable<DashboardEventRow> NextUp =>
        Rows.Where(r => r.IsUpcoming).OrderBy(r => r.Event.EventDate).Take(5);
}

/// <summary>Used by the categories, enrolments and results pages.</summary>
public class EventManagementViewModel
{
    /// <summary>The event being managed. Null when the Organiser still has to choose one.</summary>
    public EventDto? Event { get; set; }

    /// <summary>The Organiser's events, shown as a picker when no event is selected.</summary>
    public List<EventDto> MyEvents { get; set; } = new();

    public List<CategoryDto> Categories { get; set; } = new();

    public List<EnrolmentDto> Enrolments { get; set; } = new();

    public Dictionary<int, ResultDto> ResultsByEnrolment { get; set; } = new();

    public string? LoadError { get; set; }

    public bool HasEnded => Event is not null && Event.EventDate <= DateTime.Now;
}
