using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using RaceDay.Mvc.Services;

var builder = WebApplication.CreateBuilder(args);

// ---- configuration: where is the RaceDay REST API? ----
builder.Services.Configure<ApiSettings>(builder.Configuration.GetSection(ApiSettings.SectionName));

// ---- MVC. Every POST is protected against cross-site request forgery. ----
builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
});

// ---- session: remembers who is signed in (user id, role) and the API session cookie ----
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = ".RaceDay.Mvc.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.IdleTimeout = TimeSpan.FromMinutes(60);
});

builder.Services.AddHttpContextAccessor();

// ---- typed HttpClient for the API. Cookies are replayed manually per user (see RaceDayApi). ----
builder.Services
    .AddHttpClient<IRaceDayApi, RaceDayApi>((serviceProvider, client) =>
    {
        var settings = serviceProvider.GetRequiredService<IOptions<ApiSettings>>().Value;
        var baseUrl = settings.BaseUrl.EndsWith("/") ? settings.BaseUrl : settings.BaseUrl + "/";

        client.BaseAddress = new Uri(baseUrl);
        client.Timeout = TimeSpan.FromSeconds(settings.TimeoutSeconds);
    })
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler { UseCookies = false });

var app = builder.Build();

// ---- friendly errors: never show a raw exception page or status text to the user ----
app.UseExceptionHandler("/Home/Error");
app.UseStatusCodePagesWithReExecute("/Home/StatusPage", "?code={0}");

// Inside Docker the site listens on plain HTTP, so only redirect to HTTPS when running locally.
var runningInContainer = string.Equals(
    Environment.GetEnvironmentVariable("DOTNET_RUNNING_IN_CONTAINER"),
    "true",
    StringComparison.OrdinalIgnoreCase);

if (!runningInContainer)
{
    app.UseHttpsRedirection();
}

app.UseStaticFiles();
app.UseRouting();

// A fixed culture keeps number and date handling identical locally and inside the container.
var culture = CultureInfo.InvariantCulture;
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(culture),
    SupportedCultures = new List<CultureInfo> { culture },
    SupportedUICultures = new List<CultureInfo> { culture }
});

app.UseSession();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
