// Small progressive enhancements. The site works without JavaScript.
document.addEventListener("DOMContentLoaded", function () {
  // Confirm before submitting any form that declares data-confirm="message".
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      if (!window.confirm(form.getAttribute("data-confirm"))) {
        event.preventDefault();
      }
    });
  });

  // Disable submit buttons after the first click so a slow API call is not sent twice.
  document.querySelectorAll("form[data-once]").forEach(function (form) {
    form.addEventListener("submit", function () {
      form.querySelectorAll("button[type=submit]").forEach(function (button) {
        button.disabled = true;
      });
    });
  });
});
