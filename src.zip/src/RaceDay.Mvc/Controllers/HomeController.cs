using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

public class HomeController : RaceDayController
{
    public HomeController(IRaceDayApi api) : base(api)
    {
    }

    /// <summary>
    /// Visitors see the landing page, Organisers are sent to their dashboard,
    /// Participants see all upcoming events with filters.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index(EventFilterViewModel filter)
    {
        var user = HttpContext.GetCurrentUser();

        if (user is null)
        {
            return View("Landing");
        }

        if (user.IsOrganiser)
        {
            return RedirectToAction("Dashboard", "Organiser");
        }

        var model = await BuildEventListAsync(filter, "Home", "Index", "Upcoming events");
        return View(model);
    }

    // No [HttpGet] / antiforgery here: when a POST fails, the exception handler re-executes
    // this action with the original (POST) request, and it must still render.
    [IgnoreAntiforgeryToken]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        ViewData["RequestId"] = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
        return View();
    }

    /// <summary>Friendly page for 403 / 404 and other status codes (see UseStatusCodePagesWithReExecute).</summary>
    [IgnoreAntiforgeryToken]
    public IActionResult StatusPage(int code = 404)
    {
        ViewData["Code"] = code;
        Response.StatusCode = code;
        return View();
    }
}
