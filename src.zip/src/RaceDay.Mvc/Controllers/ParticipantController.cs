using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

/// <summary>Pages that only a Participant can see: their entries and their race history.</summary>
[RequireLogin(Roles.Participant)]
public class ParticipantController : RaceDayController
{
    public ParticipantController(IRaceDayApi api) : base(api)
    {
    }

    [HttpGet]
    public async Task<IActionResult> MyEnrolments()
    {
        var model = new MyEnrolmentsViewModel();
        var result = await Api.GetMyEnrolmentsAsync();

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (result.Success && result.Data is not null)
        {
            model.Enrolments = result.Data;
        }
        else
        {
            model.LoadError = result.Message;
        }

        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> MyResults()
    {
        var model = new MyResultsViewModel();
        var result = await Api.GetMyResultsAsync();

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (result.Success && result.Data is not null)
        {
            model.Results = result.Data;
        }
        else
        {
            model.LoadError = result.Message;
        }

        return View(model);
    }
}
