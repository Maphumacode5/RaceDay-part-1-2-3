using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models.Api;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

[RequireLogin(Roles.Organiser)]
public class OrganiserController : RaceDayController
{
    public OrganiserController(IRaceDayApi api) : base(api)
    {
    }

    /// <summary>Summary of the Organiser's events: enrolments per event and upcoming dates.</summary>
    [HttpGet]
    public async Task<IActionResult> Dashboard()
    {
        var model = new OrganiserDashboardViewModel();

        var (events, eventsResult) = await LoadMyEventsAsync();

        if (!eventsResult.Success)
        {
            model.LoadError = eventsResult.Message;
            return View(model);
        }

        foreach (var item in events)
        {
            var enrolments = await Api.GetEventEnrolmentsAsync(item.EventId);

            if (enrolments.IsUnauthorized)
            {
                return SessionExpired();
            }

            var list = enrolments.Success && enrolments.Data is not null
                ? enrolments.Data
                : new List<EnrolmentDto>();

            model.Rows.Add(new DashboardEventRow
            {
                Event = item,
                TotalEnrolments = list.Count(e => e.Status != "Cancelled"),
                PendingEnrolments = list.Count(e => e.Status == "Pending"),
                ConfirmedEnrolments = list.Count(e => e.Status == "Confirmed")
            });
        }

        return View(model);
    }
}
