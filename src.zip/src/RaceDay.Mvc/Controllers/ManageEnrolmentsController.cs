using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

/// <summary>View everyone who entered an event and confirm or cancel their entry (Organiser only).</summary>
[RequireLogin(Roles.Organiser)]
public class ManageEnrolmentsController : RaceDayController
{
    private static readonly string[] AllowedStatuses = { "Pending", "Confirmed", "Cancelled" };

    public ManageEnrolmentsController(IRaceDayApi api) : base(api)
    {
    }

    [HttpGet]
    public async Task<IActionResult> Index(int? eventId)
    {
        var model = new EventManagementViewModel();
        var (events, eventsResult) = await LoadMyEventsAsync();

        if (!eventsResult.Success)
        {
            model.LoadError = eventsResult.Message;
            return View(model);
        }

        model.MyEvents = events;

        if (eventId is null)
        {
            return View(model);
        }

        var selected = events.FirstOrDefault(e => e.EventId == eventId.Value);

        if (selected is null)
        {
            return NotFound();
        }

        model.Event = selected;

        var enrolments = await Api.GetEventEnrolmentsAsync(selected.EventId);

        if (enrolments.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (enrolments.Success && enrolments.Data is not null)
        {
            model.Enrolments = enrolments.Data.OrderBy(e => e.ParticipantName).ToList();
        }
        else
        {
            model.LoadError = enrolments.Message;
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> UpdateStatus(int eventId, int enrolmentId, string status)
    {
        if (!AllowedStatuses.Contains(status))
        {
            FlashError("That is not a valid enrolment status.");
            return RedirectToAction(nameof(Index), new { eventId });
        }

        var result = await Api.UpdateEnrolmentStatusAsync(enrolmentId, status);

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (result.IsForbidden)
        {
            return RedirectToAction("AccessDenied", "Account");
        }

        if (result.Success)
        {
            FlashSuccess("Enrolment marked as " + status + ".");
        }
        else
        {
            FlashError(result.Message);
        }

        return RedirectToAction(nameof(Index), new { eventId });
    }
}
