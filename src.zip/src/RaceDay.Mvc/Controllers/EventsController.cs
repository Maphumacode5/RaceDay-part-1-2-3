using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models.Api;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

/// <summary>Event browsing and details for any signed-in user; entering an event is Participant-only.</summary>
[RequireLogin]
public class EventsController : RaceDayController
{
    public EventsController(IRaceDayApi api) : base(api)
    {
    }

    [HttpGet]
    public async Task<IActionResult> Index(EventFilterViewModel filter)
    {
        var model = await BuildEventListAsync(filter, "Events", "Index", "Browse events");
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var eventResult = await Api.GetEventAsync(id);
        var failure = HandleCommonFailure(eventResult);

        if (failure is not null)
        {
            return failure;
        }

        if (!eventResult.Success || eventResult.Data is null)
        {
            FlashError(eventResult.Message);
            return RedirectToAction(nameof(Index));
        }

        var user = CurrentUser;

        var model = new EventDetailViewModel
        {
            Event = eventResult.Data,
            Categories = eventResult.Data.Categories ?? new List<CategoryDto>(),
            IsParticipant = user.IsParticipant,
            IsOwner = user.IsOrganiser && eventResult.Data.OrganiserId == user.UserId
        };

        if (user.IsParticipant)
        {
            var mine = await Api.GetMyEnrolmentsAsync();

            if (mine.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (mine.Success && mine.Data is not null)
            {
                model.ExistingEnrolment = mine.Data.FirstOrDefault(e => e.EventId == id);
            }
        }

        return View(model);
    }

    [HttpPost]
    [RequireLogin(Roles.Participant)]
    public async Task<IActionResult> Enrol(int id, int categoryId)
    {
        if (categoryId <= 0)
        {
            FlashError("Choose a category before entering the event.");
            return RedirectToAction(nameof(Details), new { id });
        }

        var eventResult = await Api.GetEventAsync(id);
        var failure = HandleCommonFailure(eventResult);

        if (failure is not null)
        {
            return failure;
        }

        if (!eventResult.Success || eventResult.Data is null)
        {
            FlashError(eventResult.Message);
            return RedirectToAction(nameof(Index));
        }

        if (eventResult.Data.EventDate < DateTime.Now)
        {
            FlashError("This event has already taken place, so entries are closed.");
            return RedirectToAction(nameof(Details), new { id });
        }

        var result = await Api.EnrolAsync(id, categoryId);

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (!result.Success)
        {
            FlashError(result.Message);
            return RedirectToAction(nameof(Details), new { id });
        }

        FlashSuccess("You are in! Your entry is pending until the organiser confirms it.");
        return RedirectToAction("MyEnrolments", "Participant");
    }
}
