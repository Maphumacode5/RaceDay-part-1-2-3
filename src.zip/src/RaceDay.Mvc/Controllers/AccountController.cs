using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models.Api;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

public class AccountController : RaceDayController
{
    public AccountController(IRaceDayApi api) : base(api)
    {
    }

    // ------------------------------------------------------------------ login

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        var user = HttpContext.GetCurrentUser();

        if (user is not null)
        {
            return RedirectToHome(user.Role);
        }

        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        // Start from a clean MVC session so nothing from a previous user can leak through.
        HttpContext.Session.Clear();

        var login = await Api.LoginAsync(model.Email.Trim(), model.Password);

        if (!login.Success || login.Data is null)
        {
            ModelState.AddModelError(
                string.Empty,
                login.IsUnauthorized ? "Invalid email or password." : login.Message);
            return View(model);
        }

        var profile = await Api.GetProfileAsync();
        var displayName = profile.Success && profile.Data is not null ? profile.Data.FirstName : "Runner";

        HttpContext.Session.SetInt32(SessionKeys.UserId, login.Data.UserId);
        HttpContext.Session.SetString(SessionKeys.Role, login.Data.Role);
        HttpContext.Session.SetString(SessionKeys.DisplayName, displayName);

        var picture = profile.Data?.ProfilePictureUrl;

        if (!string.IsNullOrEmpty(picture))
        {
            HttpContext.Session.SetString(SessionKeys.ProfilePictureUrl, picture);
        }

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
        {
            return LocalRedirect(model.ReturnUrl);
        }

        return RedirectToHome(login.Data.Role);
    }

    // ------------------------------------------------------------------ register

    [HttpGet]
    public IActionResult Register()
    {
        var user = HttpContext.GetCurrentUser();

        if (user is not null)
        {
            return RedirectToHome(user.Role);
        }

        return View(new RegisterViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (model.Role != Roles.Organiser && model.Role != Roles.Participant)
        {
            ModelState.AddModelError(nameof(model.Role), "Choose Participant or Organiser.");
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var phone = string.IsNullOrWhiteSpace(model.PhoneNumber) ? null : model.PhoneNumber.Trim();

        var result = await Api.RegisterAsync(new RegisterPayload(
            model.FirstName.Trim(),
            model.LastName.Trim(),
            model.Email.Trim(),
            model.Password,
            model.Role,
            phone));

        if (!result.Success)
        {
            if (result.StatusCode == 409)
            {
                ModelState.AddModelError(nameof(model.Email), "That email address is already registered.");
            }
            else
            {
                ModelState.AddModelError(string.Empty, result.Message);
            }

            return View(model);
        }

        FlashSuccess("Your account has been created. Sign in to get started.");
        return RedirectToAction(nameof(Login));
    }

    // ------------------------------------------------------------------ logout

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await Api.LogoutAsync();
        HttpContext.Session.Clear();

        FlashSuccess("You have been signed out.");
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult AccessDenied()
    {
        Response.StatusCode = StatusCodes.Status403Forbidden;
        return View();
    }

    // ------------------------------------------------------------------ profile

    [HttpGet]
    [RequireLogin]
    public async Task<IActionResult> Profile()
    {
        var result = await Api.GetProfileAsync();

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (!result.Success || result.Data is null)
        {
            FlashError(result.Message);
            return RedirectToAction("Index", "Home");
        }

        return View(ToViewModel(result.Data));
    }

    [HttpPost]
    [RequireLogin]
    public async Task<IActionResult> Profile(ProfileViewModel model)
    {
        if (!ModelState.IsValid)
        {
            await FillReadOnlyDetailsAsync(model);
            return View(model);
        }

        var phone = string.IsNullOrWhiteSpace(model.PhoneNumber) ? null : model.PhoneNumber.Trim();
        var result = await Api.UpdateProfileAsync(model.FirstName.Trim(), model.LastName.Trim(), phone);

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty, result.Message);
            await FillReadOnlyDetailsAsync(model);
            return View(model);
        }

        HttpContext.Session.SetString(SessionKeys.DisplayName, result.Data.FirstName);

        FlashSuccess("Your profile has been updated.");
        return RedirectToAction(nameof(Profile));
    }

    [HttpPost]
    [RequireLogin]
    public async Task<IActionResult> UploadPicture(IFormFile? picture)
    {
        if (!ImageUploadRules.HasFile(picture))
        {
            FlashError("Choose an image to upload.");
            return RedirectToAction(nameof(Profile));
        }

        var problem = ImageUploadRules.Check(picture);

        if (problem is not null)
        {
            FlashError(problem);
            return RedirectToAction(nameof(Profile));
        }

        var result = await Api.UploadProfilePictureAsync(picture!);

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (!result.Success)
        {
            FlashError(result.Message);
            return RedirectToAction(nameof(Profile));
        }

        var url = result.Data?.ProfilePictureUrl;

        if (!string.IsNullOrEmpty(url))
        {
            HttpContext.Session.SetString(SessionKeys.ProfilePictureUrl, url);
        }

        FlashSuccess("Your profile picture has been updated.");
        return RedirectToAction(nameof(Profile));
    }

    // ------------------------------------------------------------------ helpers

    private IActionResult RedirectToHome(string role) =>
        role == Roles.Organiser
            ? RedirectToAction("Dashboard", "Organiser")
            : RedirectToAction("Index", "Home");

    private static ProfileViewModel ToViewModel(UserDto user) => new()
    {
        FirstName = user.FirstName,
        LastName = user.LastName,
        PhoneNumber = user.PhoneNumber,
        Email = user.Email,
        Role = user.Role,
        ProfilePictureUrl = user.ProfilePictureUrl
    };

    private async Task FillReadOnlyDetailsAsync(ProfileViewModel model)
    {
        var current = await Api.GetProfileAsync();

        if (current.Success && current.Data is not null)
        {
            model.Email = current.Data.Email;
            model.Role = current.Data.Role;
            model.ProfilePictureUrl = current.Data.ProfilePictureUrl;
        }
    }
}
