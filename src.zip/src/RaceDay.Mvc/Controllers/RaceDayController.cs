using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models.Api;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

/// <summary>Base class with the helpers every RaceDay controller needs.</summary>
public abstract class RaceDayController : Controller
{
    protected RaceDayController(IRaceDayApi api)
    {
        Api = api;
    }

    protected IRaceDayApi Api { get; }

    /// <summary>The signed-in user. Only call this on actions protected by [RequireLogin].</summary>
    protected CurrentUser CurrentUser => HttpContext.GetCurrentUser()!;

    protected void FlashSuccess(string message) => TempData["Success"] = message;

    protected void FlashError(string message) => TempData["Error"] = message;

    protected void FlashWarning(string message) => TempData["Warning"] = message;

    /// <summary>The API session ended (timeout or restart): clear ours and ask the user to sign in again.</summary>
    protected IActionResult SessionExpired()
    {
        HttpContext.Session.Clear();
        FlashError("Your session has expired. Please sign in again.");
        return RedirectToAction("Login", "Account");
    }

    /// <summary>Maps API 401 / 403 / 404 onto the matching MVC response. Returns null for any other outcome.</summary>
    protected IActionResult? HandleCommonFailure(ApiResult result)
    {
        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (result.IsForbidden)
        {
            return RedirectToAction("AccessDenied", "Account");
        }

        if (result.IsNotFound)
        {
            return NotFound();
        }

        return null;
    }

    /// <summary>Joins all model validation messages into one sentence for a flash message.</summary>
    protected string ModelErrors() =>
        string.Join(
            " ",
            ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .Where(m => !string.IsNullOrWhiteSpace(m)));

    /// <summary>Loads the events and keeps only those owned by the signed-in Organiser.</summary>
    protected async Task<(List<EventDto> Events, ApiResult Result)> LoadMyEventsAsync()
    {
        var result = await Api.GetEventsAsync();

        var mine = result.Success && result.Data is not null
            ? result.Data.Where(e => e.OrganiserId == CurrentUser.UserId).OrderBy(e => e.EventDate).ToList()
            : new List<EventDto>();

        return (mine, result);
    }

    /// <summary>Builds the filtered event list used by the Participant home page and the event browser.</summary>
    protected async Task<EventListViewModel> BuildEventListAsync(
        EventFilterViewModel filter, string controller, string action, string heading)
    {
        var model = new EventListViewModel
        {
            Filter = filter,
            FormController = controller,
            FormAction = action,
            Heading = heading
        };

        DateTime? from = filter.IncludePast ? null : DateTime.Today;
        var result = await Api.GetEventsAsync(null, from);

        if (result.Success && result.Data is not null)
        {
            model.TotalCount = result.Data.Count;
            model.Events = EventFiltering.Apply(result.Data, filter);
        }
        else
        {
            model.LoadError = result.Message;
        }

        return model;
    }
}
