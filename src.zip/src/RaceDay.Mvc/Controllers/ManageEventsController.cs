using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models.Api;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

/// <summary>Create, edit and delete events (Organiser only), including the banner image.</summary>
[RequireLogin(Roles.Organiser)]
public class ManageEventsController : RaceDayController
{
    public ManageEventsController(IRaceDayApi api) : base(api)
    {
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var (events, result) = await LoadMyEventsAsync();

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        var model = new EventManagementViewModel { MyEvents = events };

        if (!result.Success)
        {
            model.LoadError = result.Message;
        }

        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var model = new EventFormViewModel
        {
            EventDate = DateTime.Today.AddDays(30).AddHours(6),
            EventTypes = await LoadEventTypesAsync()
        };

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Create(EventFormViewModel model)
    {
        var bannerProblem = ImageUploadRules.Check(model.BannerImage);

        if (bannerProblem is not null)
        {
            ModelState.AddModelError(nameof(model.BannerImage), bannerProblem);
        }

        if (!ModelState.IsValid)
        {
            model.EventTypes = await LoadEventTypesAsync();
            return View(model);
        }

        var result = await Api.CreateEventAsync(ToPayload(model));

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (!result.Success || result.Data is null)
        {
            ModelState.AddModelError(string.Empty, result.Message);
            model.EventTypes = await LoadEventTypesAsync();
            return View(model);
        }

        if (ImageUploadRules.HasFile(model.BannerImage))
        {
            var upload = await Api.UploadBannerAsync(result.Data.EventId, model.BannerImage!);

            if (!upload.Success)
            {
                FlashWarning("The event was created, but the banner could not be uploaded: " + upload.Message);
                return RedirectToAction(nameof(Index));
            }
        }

        FlashSuccess("\"" + model.Name.Trim() + "\" has been created.");
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var current = await Api.GetEventAsync(id);
        var failure = HandleCommonFailure(current);

        if (failure is not null)
        {
            return failure;
        }

        if (!current.Success || current.Data is null)
        {
            FlashError(current.Message);
            return RedirectToAction(nameof(Index));
        }

        if (current.Data.OrganiserId != CurrentUser.UserId)
        {
            return RedirectToAction("AccessDenied", "Account");
        }

        var model = new EventFormViewModel
        {
            EventId = current.Data.EventId,
            Name = current.Data.Name,
            Description = current.Data.Description,
            EventDate = current.Data.EventDate,
            Location = current.Data.Location,
            DistanceKm = current.Data.DistanceKm,
            EventTypeId = 0,
            ExistingBannerUrl = current.Data.BannerImageUrl,
            EventTypes = await LoadEventTypesAsync()
        };

        // The API returns the type name; find its id for the drop-down.
        var match = model.EventTypes.FirstOrDefault(t =>
            string.Equals(t.TypeName, current.Data.EventType, StringComparison.OrdinalIgnoreCase));

        model.EventTypeId = match?.EventTypeId ?? 0;

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, EventFormViewModel model)
    {
        model.EventId = id;

        var bannerProblem = ImageUploadRules.Check(model.BannerImage);

        if (bannerProblem is not null)
        {
            ModelState.AddModelError(nameof(model.BannerImage), bannerProblem);
        }

        if (!ModelState.IsValid)
        {
            await FillEditExtrasAsync(model);
            return View(model);
        }

        var result = await Api.UpdateEventAsync(id, ToPayload(model));
        var failure = HandleCommonFailure(result);

        if (failure is not null)
        {
            return failure;
        }

        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Message);
            await FillEditExtrasAsync(model);
            return View(model);
        }

        if (ImageUploadRules.HasFile(model.BannerImage))
        {
            var upload = await Api.UploadBannerAsync(id, model.BannerImage!);

            if (!upload.Success)
            {
                FlashWarning("The event was updated, but the banner could not be uploaded: " + upload.Message);
                return RedirectToAction(nameof(Index));
            }
        }

        FlashSuccess("\"" + model.Name.Trim() + "\" has been updated.");
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var result = await Api.DeleteEventAsync(id);

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (result.IsForbidden)
        {
            return RedirectToAction("AccessDenied", "Account");
        }

        if (result.Success)
        {
            FlashSuccess("The event has been deleted.");
        }
        else
        {
            FlashError(result.Message);
        }

        return RedirectToAction(nameof(Index));
    }

    // ------------------------------------------------------------------ helpers

    private async Task<List<EventTypeDto>> LoadEventTypesAsync()
    {
        var result = await Api.GetEventTypesAsync();

        if (result.Success && result.Data is not null && result.Data.Count > 0)
        {
            return result.Data;
        }

        // Fall back to the lookup rows seeded by the Part 1 SQL script so the form still renders.
        return new List<EventTypeDto>
        {
            new EventTypeDto(1, "Run"),
            new EventTypeDto(2, "Walk"),
            new EventTypeDto(3, "Cycle")
        };
    }

    private async Task FillEditExtrasAsync(EventFormViewModel model)
    {
        model.EventTypes = await LoadEventTypesAsync();

        var current = await Api.GetEventAsync(model.EventId);

        if (current.Success && current.Data is not null)
        {
            model.ExistingBannerUrl = current.Data.BannerImageUrl;
        }
    }

    private static EventPayload ToPayload(EventFormViewModel model) => new(
        model.Name.Trim(),
        string.IsNullOrWhiteSpace(model.Description) ? null : model.Description.Trim(),
        model.EventDate!.Value,
        model.Location.Trim(),
        model.DistanceKm,
        model.EventTypeId);
}
