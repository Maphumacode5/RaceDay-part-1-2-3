using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

/// <summary>Add, rename and remove the age / distance categories of an event (Organiser only).</summary>
[RequireLogin(Roles.Organiser)]
public class ManageCategoriesController : RaceDayController
{
    public ManageCategoriesController(IRaceDayApi api) : base(api)
    {
    }

    /// <summary>Shows an event picker, or the categories of the chosen event.</summary>
    [HttpGet]
    public async Task<IActionResult> Index(int? eventId)
    {
        var model = new EventManagementViewModel();
        var (events, eventsResult) = await LoadMyEventsAsync();

        if (!eventsResult.Success)
        {
            model.LoadError = eventsResult.Message;
            return View(model);
        }

        model.MyEvents = events;

        if (eventId is null)
        {
            return View(model);
        }

        var selected = events.FirstOrDefault(e => e.EventId == eventId.Value);

        if (selected is null)
        {
            return NotFound();
        }

        model.Event = selected;

        var categories = await Api.GetCategoriesAsync(selected.EventId);

        if (categories.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (categories.Success && categories.Data is not null)
        {
            model.Categories = categories.Data;
        }
        else
        {
            model.LoadError = categories.Message;
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Add(CategoryFormViewModel model)
    {
        if (!ModelState.IsValid)
        {
            FlashError(ModelErrors());
            return RedirectToAction(nameof(Index), new { eventId = model.EventId });
        }

        var description = string.IsNullOrWhiteSpace(model.Description) ? null : model.Description.Trim();
        var result = await Api.CreateCategoryAsync(model.EventId, model.Name.Trim(), description);
        var failure = HandleCommonFailure(result);

        if (failure is not null)
        {
            return failure;
        }

        if (result.Success)
        {
            FlashSuccess("Category \"" + model.Name.Trim() + "\" added.");
        }
        else
        {
            FlashError(result.Message);
        }

        return RedirectToAction(nameof(Index), new { eventId = model.EventId });
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int eventId, int id)
    {
        var categories = await Api.GetCategoriesAsync(eventId);
        var failure = HandleCommonFailure(categories);

        if (failure is not null)
        {
            return failure;
        }

        var category = categories.Data?.FirstOrDefault(c => c.CategoryId == id);

        if (!categories.Success || category is null)
        {
            return NotFound();
        }

        return View(new CategoryFormViewModel
        {
            CategoryId = category.CategoryId,
            EventId = category.EventId,
            Name = category.Name,
            Description = category.Description
        });
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int eventId, int id, CategoryFormViewModel model)
    {
        model.EventId = eventId;
        model.CategoryId = id;

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var description = string.IsNullOrWhiteSpace(model.Description) ? null : model.Description.Trim();
        var result = await Api.UpdateCategoryAsync(id, model.Name.Trim(), description);
        var failure = HandleCommonFailure(result);

        if (failure is not null)
        {
            return failure;
        }

        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Message);
            return View(model);
        }

        FlashSuccess("Category updated.");
        return RedirectToAction(nameof(Index), new { eventId });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int eventId, int id)
    {
        var result = await Api.DeleteCategoryAsync(id);

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (result.IsForbidden)
        {
            return RedirectToAction("AccessDenied", "Account");
        }

        if (result.Success)
        {
            FlashSuccess("Category removed.");
        }
        else
        {
            FlashError(result.Message);
        }

        return RedirectToAction(nameof(Index), new { eventId });
    }
}
