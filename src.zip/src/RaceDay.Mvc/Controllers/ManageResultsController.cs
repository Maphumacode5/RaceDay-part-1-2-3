using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Services;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Controllers;

/// <summary>Capture and publish finish times and positions after an event has concluded (Organiser only).</summary>
[RequireLogin(Roles.Organiser)]
public class ManageResultsController : RaceDayController
{
    public ManageResultsController(IRaceDayApi api) : base(api)
    {
    }

    [HttpGet]
    public async Task<IActionResult> Index(int? eventId)
    {
        var model = new EventManagementViewModel();
        var (events, eventsResult) = await LoadMyEventsAsync();

        if (!eventsResult.Success)
        {
            model.LoadError = eventsResult.Message;
            return View(model);
        }

        model.MyEvents = events;

        if (eventId is null)
        {
            return View(model);
        }

        var selected = events.FirstOrDefault(e => e.EventId == eventId.Value);

        if (selected is null)
        {
            return NotFound();
        }

        model.Event = selected;

        var enrolments = await Api.GetEventEnrolmentsAsync(selected.EventId);

        if (enrolments.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (!enrolments.Success || enrolments.Data is null)
        {
            model.LoadError = enrolments.Message;
            return View(model);
        }

        model.Enrolments = enrolments.Data
            .Where(e => e.Status != "Cancelled")
            .OrderBy(e => e.ParticipantName)
            .ToList();

        var results = await Api.GetEventResultsAsync(selected.EventId);

        if (results.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (results.Success && results.Data is not null)
        {
            foreach (var result in results.Data)
            {
                model.ResultsByEnrolment[result.EnrolmentId] = result;
            }
        }
        else
        {
            model.LoadError = results.Message;
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Capture(
        int eventId, int enrolmentId, string? finishTime, int? finishPosition, int? totalFinishers)
    {
        if (!TimeParsing.TryParseFinishTime(finishTime, out var time))
        {
            FlashError("Enter the finish time as hh:mm:ss, for example 02:41:13.");
            return RedirectToAction(nameof(Index), new { eventId });
        }

        if (finishPosition is null || finishPosition < 1 || totalFinishers is null || totalFinishers < 1)
        {
            FlashError("Enter the finishing position and the total number of finishers (both 1 or more).");
            return RedirectToAction(nameof(Index), new { eventId });
        }

        if (finishPosition > totalFinishers)
        {
            FlashError("The finishing position cannot be greater than the total number of finishers.");
            return RedirectToAction(nameof(Index), new { eventId });
        }

        // Results are only captured once the event has concluded.
        var eventResult = await Api.GetEventAsync(eventId);
        var failure = HandleCommonFailure(eventResult);

        if (failure is not null)
        {
            return failure;
        }

        if (!eventResult.Success || eventResult.Data is null)
        {
            FlashError(eventResult.Message);
            return RedirectToAction(nameof(Index), new { eventId });
        }

        if (eventResult.Data.EventDate > DateTime.Now)
        {
            FlashError("Results can only be captured after the event has concluded.");
            return RedirectToAction(nameof(Index), new { eventId });
        }

        var result = await Api.CaptureResultAsync(enrolmentId, time, finishPosition.Value, totalFinishers.Value);

        if (result.IsUnauthorized)
        {
            return SessionExpired();
        }

        if (result.IsForbidden)
        {
            return RedirectToAction("AccessDenied", "Account");
        }

        if (result.Success)
        {
            FlashSuccess("Result captured and published to the participant.");
        }
        else
        {
            FlashError(result.Message);
        }

        return RedirectToAction(nameof(Index), new { eventId });
    }
}
