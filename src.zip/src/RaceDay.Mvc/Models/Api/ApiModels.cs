namespace RaceDay.Mvc.Models.Api;

// These records mirror the JSON contracts exposed by the RaceDay REST API (Part 2).
// The MVC project never touches the database - it only ever talks to the API with these shapes.

public record LoginResponse(string? Message, int UserId, string Role);

public record UserDto(
    int UserId,
    string FirstName,
    string LastName,
    string Email,
    string Role,
    string? PhoneNumber,
    string? ProfilePictureUrl);

public record EventDto(
    int EventId,
    string Name,
    string? Description,
    DateTime EventDate,
    string Location,
    decimal DistanceKm,
    string EventType,
    int OrganiserId,
    string? BannerImageUrl);

public record CategoryDto(
    int CategoryId,
    int EventId,
    string Name,
    string? Description);

public record EventDetailDto(
    int EventId,
    string Name,
    string? Description,
    DateTime EventDate,
    string Location,
    decimal DistanceKm,
    string? BannerImageUrl,
    string EventType,
    int OrganiserId,
    List<CategoryDto>? Categories);

public record EventTypeDto(int EventTypeId, string TypeName);

public record EnrolmentDto(
    int EnrolmentId,
    int ParticipantId,
    string ParticipantName,
    int EventId,
    string EventName,
    int CategoryId,
    string CategoryName,
    DateTime EnrolmentDate,
    string Status);

public record ResultDto(
    int ResultId,
    int EnrolmentId,
    string EventName,
    DateTime EventDate,
    string CategoryName,
    TimeSpan? FinishTime,
    int? FinishPosition,
    int? TotalFinishers);

/// <summary>Response from the banner / profile picture upload endpoints.</summary>
public record UploadResponse(string? Message, string? BannerImageUrl, string? ProfilePictureUrl);

/// <summary>Placeholder used when an API call returns no useful body.</summary>
public record EmptyBody;

// ----- request payloads sent to the API -----

public record RegisterPayload(
    string FirstName,
    string LastName,
    string Email,
    string Password,
    string Role,
    string? PhoneNumber);

public record EventPayload(
    string Name,
    string? Description,
    DateTime EventDate,
    string Location,
    decimal DistanceKm,
    int EventTypeId);
