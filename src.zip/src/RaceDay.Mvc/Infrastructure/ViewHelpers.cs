using System.Globalization;

namespace RaceDay.Mvc.Infrastructure;

/// <summary>Small formatting helpers shared by the Razor views.</summary>
public static class ViewHelpers
{
    public static string StatusClass(string? status) => status switch
    {
        "Confirmed" => "rd-badge rd-badge-confirmed",
        "Pending" => "rd-badge rd-badge-pending",
        "Cancelled" => "rd-badge rd-badge-cancelled",
        _ => "rd-badge"
    };

    public static string StatusIcon(string? status) => status switch
    {
        "Confirmed" => "bi-check-circle-fill",
        "Pending" => "bi-hourglass-split",
        "Cancelled" => "bi-x-circle-fill",
        _ => "bi-circle"
    };

    public static string EventTypeIcon(string? eventType) => eventType switch
    {
        "Walk" => "bi-person-walking",
        "Cycle" => "bi-bicycle",
        _ => "bi-lightning-charge-fill"
    };

    public static string EventTypeClass(string? eventType) => eventType switch
    {
        "Walk" => "rd-type-walk",
        "Cycle" => "rd-type-cycle",
        _ => "rd-type-run"
    };

    /// <summary>1 gives 1st, 2 gives 2nd, 11 gives 11th, 112 gives 112th, 47 gives 47th.</summary>
    public static string Ordinal(int number)
    {
        var text = number.ToString(CultureInfo.InvariantCulture);
        var lastTwo = number % 100;

        if (lastTwo >= 11 && lastTwo <= 13)
        {
            return text + "th";
        }

        switch (number % 10)
        {
            case 1: return text + "st";
            case 2: return text + "nd";
            case 3: return text + "rd";
            default: return text + "th";
        }
    }

    /// <summary>Formats a finish time as hh:mm:ss, or an em dash when there is none.</summary>
    public static string FormatTime(TimeSpan? time)
    {
        if (time is null)
        {
            return "\u2014";
        }

        var value = time.Value;
        return string.Format(
            CultureInfo.InvariantCulture,
            "{0:00}:{1:00}:{2:00}",
            (int)value.TotalHours,
            value.Minutes,
            value.Seconds);
    }

    /// <summary>"47th of 312" style position text.</summary>
    public static string FormatPosition(int? position, int? totalFinishers)
    {
        if (position is null)
        {
            return "\u2014";
        }

        if (totalFinishers is null)
        {
            return Ordinal(position.Value);
        }

        return Ordinal(position.Value) + " of " + totalFinishers.Value.ToString(CultureInfo.InvariantCulture);
    }

    public static string FormatDate(DateTime date) =>
        date.ToString("ddd, dd MMM yyyy", CultureInfo.InvariantCulture);

    public static string FormatShortDate(DateTime date) =>
        date.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);

    public static string FormatDateTime(DateTime date) =>
        date.ToString("ddd, dd MMM yyyy, HH:mm", CultureInfo.InvariantCulture);

    public static string FormatDistance(decimal kilometres) =>
        kilometres.ToString("0.##", CultureInfo.InvariantCulture) + " km";

    /// <summary>Value for an input of type datetime-local.</summary>
    public static string ToInputDateTime(DateTime date) =>
        date.ToString("yyyy-MM-dd'T'HH:mm", CultureInfo.InvariantCulture);
}
