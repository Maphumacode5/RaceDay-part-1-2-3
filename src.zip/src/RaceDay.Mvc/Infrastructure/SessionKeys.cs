namespace RaceDay.Mvc.Infrastructure;

/// <summary>Keys used in the MVC application session.</summary>
public static class SessionKeys
{
    public const string UserId = "UserId";
    public const string Role = "Role";
    public const string DisplayName = "DisplayName";
    public const string ProfilePictureUrl = "ProfilePictureUrl";

    /// <summary>The "name=value" of the API session cookie, forwarded on every API call.</summary>
    public const string ApiCookie = "ApiSessionCookie";
}
