using RaceDay.Mvc.Models.Api;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Infrastructure;

public static class EventFiltering
{
    /// <summary>Applies the search, type, distance and sort options chosen on the filter bar.</summary>
    public static List<EventDto> Apply(IEnumerable<EventDto> events, EventFilterViewModel filter)
    {
        IEnumerable<EventDto> query = events;

        if (!string.IsNullOrWhiteSpace(filter.Search))
        {
            var term = filter.Search.Trim();

            query = query.Where(e =>
                e.Name.Contains(term, StringComparison.OrdinalIgnoreCase)
                || e.Location.Contains(term, StringComparison.OrdinalIgnoreCase)
                || (e.Description != null && e.Description.Contains(term, StringComparison.OrdinalIgnoreCase)));
        }

        if (!string.IsNullOrWhiteSpace(filter.Type)
            && !string.Equals(filter.Type, "All", StringComparison.OrdinalIgnoreCase))
        {
            query = query.Where(e => string.Equals(e.EventType, filter.Type, StringComparison.OrdinalIgnoreCase));
        }

        switch (filter.Distance)
        {
            case "short":
                query = query.Where(e => e.DistanceKm <= 5m);
                break;
            case "medium":
                query = query.Where(e => e.DistanceKm > 5m && e.DistanceKm <= 15m);
                break;
            case "long":
                query = query.Where(e => e.DistanceKm > 15m && e.DistanceKm <= 42.2m);
                break;
            case "ultra":
                query = query.Where(e => e.DistanceKm > 42.2m);
                break;
        }

        switch (filter.Sort)
        {
            case "distance":
                query = query.OrderBy(e => e.DistanceKm);
                break;
            case "name":
                query = query.OrderBy(e => e.Name, StringComparer.OrdinalIgnoreCase);
                break;
            default:
                query = query.OrderBy(e => e.EventDate);
                break;
        }

        return query.ToList();
    }
}
