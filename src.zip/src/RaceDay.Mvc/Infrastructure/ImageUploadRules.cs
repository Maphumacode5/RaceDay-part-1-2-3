namespace RaceDay.Mvc.Infrastructure;

/// <summary>
/// First line of defence for image uploads. The API repeats these checks (and inspects the
/// file signature), so the rules here exist to give the user an immediate, friendly message.
/// </summary>
public static class ImageUploadRules
{
    public const long MaxBytes = 5 * 1024 * 1024;

    private static readonly string[] AllowedTypes =
    {
        "image/jpeg", "image/png", "image/gif", "image/webp"
    };

    /// <summary>Returns null when the file is fine (or absent), otherwise a message to show the user.</summary>
    public static string? Check(IFormFile? file)
    {
        if (file is null || file.Length == 0)
        {
            return null;
        }

        if (file.Length > MaxBytes)
        {
            return "The image must be 5 MB or smaller.";
        }

        if (!AllowedTypes.Contains(file.ContentType, StringComparer.OrdinalIgnoreCase))
        {
            return "Please choose a JPEG, PNG, GIF or WebP image.";
        }

        return null;
    }

    /// <summary>True when a file was actually chosen.</summary>
    public static bool HasFile(IFormFile? file) => file is not null && file.Length > 0;
}
