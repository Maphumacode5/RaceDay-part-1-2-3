namespace RaceDay.Mvc.Infrastructure;

/// <summary>The two roles supported by the RaceDay API.</summary>
public static class Roles
{
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";
}
