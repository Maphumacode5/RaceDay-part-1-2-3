using System.Globalization;

namespace RaceDay.Mvc.Infrastructure;

public static class TimeParsing
{
    private static readonly string[] Formats = { @"h\:mm\:ss", @"hh\:mm\:ss" };

    /// <summary>Parses a finish time such as 02:41:13 (hh:mm:ss). Zero or negative times are rejected.</summary>
    public static bool TryParseFinishTime(string? text, out TimeSpan time)
    {
        time = TimeSpan.Zero;

        if (string.IsNullOrWhiteSpace(text))
        {
            return false;
        }

        if (!TimeSpan.TryParseExact(text.Trim(), Formats, CultureInfo.InvariantCulture, out var parsed))
        {
            return false;
        }

        if (parsed <= TimeSpan.Zero)
        {
            return false;
        }

        time = parsed;
        return true;
    }
}
