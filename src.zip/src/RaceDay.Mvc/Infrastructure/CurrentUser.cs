namespace RaceDay.Mvc.Infrastructure;

/// <summary>The signed-in user, as remembered in the MVC session.</summary>
public sealed record CurrentUser(int UserId, string Role, string DisplayName, string? ProfilePictureUrl)
{
    public bool IsOrganiser => Role == Roles.Organiser;

    public bool IsParticipant => Role == Roles.Participant;

    /// <summary>First letter of the display name, used for the avatar placeholder.</summary>
    public string Initials
    {
        get
        {
            var name = DisplayName.Trim();
            return name.Length == 0 ? "?" : name.Substring(0, 1).ToUpperInvariant();
        }
    }
}
