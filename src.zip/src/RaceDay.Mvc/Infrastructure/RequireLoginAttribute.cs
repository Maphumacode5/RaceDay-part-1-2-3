using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Mvc.Infrastructure;

/// <summary>
/// Protects a controller or action. Unauthenticated visitors are sent to the login page;
/// signed-in users with the wrong role are sent to the access-denied page.
/// Used as <c>[RequireLogin]</c> (any role) or <c>[RequireLogin(Roles.Organiser)]</c>.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequireLoginAttribute : ActionFilterAttribute
{
    public RequireLoginAttribute()
    {
    }

    public RequireLoginAttribute(string role)
    {
        Role = role;
    }

    public string? Role { get; }

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        var user = context.HttpContext.GetCurrentUser();

        if (user is null)
        {
            if (context.Controller is Controller controller)
            {
                controller.TempData["Error"] = "Please sign in to continue.";
            }

            var request = context.HttpContext.Request;
            string? returnUrl = null;

            if (HttpMethods.IsGet(request.Method))
            {
                returnUrl = request.Path.Value + request.QueryString.Value;
            }

            context.Result = new RedirectToActionResult("Login", "Account", new { returnUrl });
            return;
        }

        if (Role is not null && !string.Equals(user.Role, Role, StringComparison.Ordinal))
        {
            context.Result = new RedirectToActionResult("AccessDenied", "Account", null);
        }
    }
}
