namespace RaceDay.Mvc.Infrastructure;

public static class HttpContextExtensions
{
    /// <summary>Returns the signed-in user from the session, or null when nobody is signed in.</summary>
    public static CurrentUser? GetCurrentUser(this HttpContext context)
    {
        var session = context.Session;
        var userId = session.GetInt32(SessionKeys.UserId);
        var role = session.GetString(SessionKeys.Role);

        if (userId is null || string.IsNullOrEmpty(role))
        {
            return null;
        }

        return new CurrentUser(
            userId.Value,
            role,
            session.GetString(SessionKeys.DisplayName) ?? "Runner",
            session.GetString(SessionKeys.ProfilePictureUrl));
    }
}
