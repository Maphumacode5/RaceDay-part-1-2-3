namespace RaceDay.Mvc.Services;

/// <summary>Where the RaceDay REST API lives. Bound from the "ApiSettings" configuration section.</summary>
public class ApiSettings
{
    public const string SectionName = "ApiSettings";

    public string BaseUrl { get; set; } = "https://localhost:7132/";

    public int TimeoutSeconds { get; set; } = 30;
}
