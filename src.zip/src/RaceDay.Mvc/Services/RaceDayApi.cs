using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using System.Text.Json;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models.Api;

namespace RaceDay.Mvc.Services;

/// <summary>
/// Typed HttpClient for the RaceDay REST API.
///
/// The API keeps the user's login in a server-side session identified by the ".RaceDay.Session"
/// cookie. Because this class runs on the web server (not in the browser), it captures that
/// cookie from the login response, keeps it in the MVC user's own session, and replays it as a
/// Cookie header on every later call. Cookies are deliberately NOT shared through a global
/// cookie container - that would mix up different users.
/// </summary>
public class RaceDayApi : IRaceDayApi
{
    public const string SessionCookieName = ".RaceDay.Session";

    private const string Unavailable =
        "The RaceDay service is temporarily unavailable. Please try again in a moment.";

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _accessor;
    private readonly ILogger<RaceDayApi> _logger;

    public RaceDayApi(HttpClient http, IHttpContextAccessor accessor, ILogger<RaceDayApi> logger)
    {
        _http = http;
        _accessor = accessor;
        _logger = logger;
    }

    private ISession? Session => _accessor.HttpContext?.Session;

    // ------------------------------------------------------------------ authentication

    public Task<ApiResult<LoginResponse>> LoginAsync(string email, string password)
    {
        var body = Json(new { email, password });

        return SendAsync<LoginResponse>(HttpMethod.Post, "api/auth/login", body, response =>
        {
            if (!response.IsSuccessStatusCode)
            {
                return;
            }

            if (response.Headers.TryGetValues("Set-Cookie", out var values))
            {
                var cookie = ExtractSessionCookie(values);

                if (cookie is not null)
                {
                    Session?.SetString(SessionKeys.ApiCookie, cookie);
                }
            }
        });
    }

    public Task<ApiResult<UserDto>> RegisterAsync(RegisterPayload payload) =>
        SendAsync<UserDto>(HttpMethod.Post, "api/auth/register", Json(payload));

    public async Task LogoutAsync()
    {
        // Best effort: whatever happens, the caller clears the MVC session afterwards.
        await SendAsync<EmptyBody>(HttpMethod.Post, "api/auth/logout", null);
    }

    // ------------------------------------------------------------------ profile

    public Task<ApiResult<UserDto>> GetProfileAsync() =>
        SendAsync<UserDto>(HttpMethod.Get, "api/users/me", null);

    public Task<ApiResult<UserDto>> UpdateProfileAsync(string firstName, string lastName, string? phoneNumber) =>
        SendAsync<UserDto>(HttpMethod.Put, "api/users/me", Json(new { firstName, lastName, phoneNumber }));

    public Task<ApiResult<UploadResponse>> UploadProfilePictureAsync(IFormFile image) =>
        SendFileAsync<UploadResponse>(HttpMethod.Put, "api/users/me/profile-picture", image);

    // ------------------------------------------------------------------ events

    public Task<ApiResult<List<EventDto>>> GetEventsAsync(string? eventType = null, DateTime? from = null)
    {
        var query = new List<string>();

        if (!string.IsNullOrWhiteSpace(eventType) && !string.Equals(eventType, "All", StringComparison.OrdinalIgnoreCase))
        {
            query.Add("eventType=" + Uri.EscapeDataString(eventType));
        }

        if (from.HasValue)
        {
            query.Add("from=" + from.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
        }

        var url = query.Count == 0 ? "api/events" : "api/events?" + string.Join("&", query);
        return SendAsync<List<EventDto>>(HttpMethod.Get, url, null);
    }

    public Task<ApiResult<EventDetailDto>> GetEventAsync(int eventId) =>
        SendAsync<EventDetailDto>(HttpMethod.Get, $"api/events/{eventId}", null);

    public Task<ApiResult<EventDto>> CreateEventAsync(EventPayload payload) =>
        SendAsync<EventDto>(HttpMethod.Post, "api/events", Json(payload));

    public Task<ApiResult<EventDto>> UpdateEventAsync(int eventId, EventPayload payload) =>
        SendAsync<EventDto>(HttpMethod.Put, $"api/events/{eventId}", Json(payload));

    public async Task<ApiResult> DeleteEventAsync(int eventId) =>
        await SendAsync<EmptyBody>(HttpMethod.Delete, $"api/events/{eventId}", null);

    public Task<ApiResult<UploadResponse>> UploadBannerAsync(int eventId, IFormFile image) =>
        SendFileAsync<UploadResponse>(HttpMethod.Post, $"api/events/{eventId}/banner", image);

    public Task<ApiResult<List<EventTypeDto>>> GetEventTypesAsync() =>
        SendAsync<List<EventTypeDto>>(HttpMethod.Get, "api/event-types", null);

    // ------------------------------------------------------------------ categories

    public Task<ApiResult<List<CategoryDto>>> GetCategoriesAsync(int eventId) =>
        SendAsync<List<CategoryDto>>(HttpMethod.Get, $"api/events/{eventId}/categories", null);

    public Task<ApiResult<CategoryDto>> CreateCategoryAsync(int eventId, string name, string? description) =>
        SendAsync<CategoryDto>(HttpMethod.Post, $"api/events/{eventId}/categories", Json(new { name, description }));

    public Task<ApiResult<CategoryDto>> UpdateCategoryAsync(int categoryId, string name, string? description) =>
        SendAsync<CategoryDto>(HttpMethod.Put, $"api/categories/{categoryId}", Json(new { name, description }));

    public async Task<ApiResult> DeleteCategoryAsync(int categoryId) =>
        await SendAsync<EmptyBody>(HttpMethod.Delete, $"api/categories/{categoryId}", null);

    // ------------------------------------------------------------------ enrolments

    public async Task<ApiResult> EnrolAsync(int eventId, int categoryId) =>
        await SendAsync<EmptyBody>(HttpMethod.Post, $"api/events/{eventId}/enrolments", Json(new { categoryId }));

    public Task<ApiResult<List<EnrolmentDto>>> GetMyEnrolmentsAsync() =>
        SendAsync<List<EnrolmentDto>>(HttpMethod.Get, "api/users/me/enrolments", null);

    public Task<ApiResult<List<EnrolmentDto>>> GetEventEnrolmentsAsync(int eventId) =>
        SendAsync<List<EnrolmentDto>>(HttpMethod.Get, $"api/events/{eventId}/enrolments", null);

    public async Task<ApiResult> UpdateEnrolmentStatusAsync(int enrolmentId, string status) =>
        await SendAsync<EmptyBody>(HttpMethod.Put, $"api/enrolments/{enrolmentId}/status", Json(new { status }));

    // ------------------------------------------------------------------ results

    public async Task<ApiResult> CaptureResultAsync(
        int enrolmentId, TimeSpan finishTime, int finishPosition, int totalFinishers) =>
        await SendAsync<EmptyBody>(
            HttpMethod.Post,
            $"api/enrolments/{enrolmentId}/results",
            Json(new { finishTime, finishPosition, totalFinishers }));

    public Task<ApiResult<List<ResultDto>>> GetMyResultsAsync() =>
        SendAsync<List<ResultDto>>(HttpMethod.Get, "api/users/me/results", null);

    public Task<ApiResult<List<ResultDto>>> GetEventResultsAsync(int eventId) =>
        SendAsync<List<ResultDto>>(HttpMethod.Get, $"api/events/{eventId}/results", null);

    // ------------------------------------------------------------------ plumbing

    /// <summary>Finds ".RaceDay.Session=value" in the Set-Cookie headers and returns "name=value".</summary>
    public static string? ExtractSessionCookie(IEnumerable<string> setCookieValues)
    {
        foreach (var value in setCookieValues)
        {
            if (value.StartsWith(SessionCookieName + "=", StringComparison.Ordinal))
            {
                var end = value.IndexOf(';');
                return end >= 0 ? value.Substring(0, end) : value;
            }
        }

        return null;
    }

    private static JsonContent Json<T>(T value) =>
        JsonContent.Create(value, mediaType: null, options: JsonOptions);

    private async Task<ApiResult<T>> SendFileAsync<T>(HttpMethod method, string url, IFormFile file)
    {
        using var form = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();

        var fileContent = new StreamContent(stream);

        if (MediaTypeHeaderValue.TryParse(file.ContentType, out var mediaType))
        {
            fileContent.Headers.ContentType = mediaType;
        }

        // The API binds the multipart field called "image".
        form.Add(fileContent, "image", "upload" + ExtensionFor(file.ContentType));

        return await SendAsync<T>(method, url, form);
    }

    private static string ExtensionFor(string? contentType)
    {
        switch (contentType?.ToLowerInvariant())
        {
            case "image/png": return ".png";
            case "image/gif": return ".gif";
            case "image/webp": return ".webp";
            default: return ".jpg";
        }
    }

    private async Task<ApiResult<T>> SendAsync<T>(
        HttpMethod method, string url, HttpContent? content, Action<HttpResponseMessage>? onResponse = null)
    {
        try
        {
            using var request = new HttpRequestMessage(method, url) { Content = content };

            var cookie = Session?.GetString(SessionKeys.ApiCookie);

            if (!string.IsNullOrEmpty(cookie))
            {
                request.Headers.TryAddWithoutValidation("Cookie", cookie);
            }

            using var response = await _http.SendAsync(request);
            onResponse?.Invoke(response);

            var status = (int)response.StatusCode;

            if (!response.IsSuccessStatusCode)
            {
                return ApiResult<T>.Fail(status, await ReadErrorAsync(response));
            }

            if (response.StatusCode == HttpStatusCode.NoContent || response.Content.Headers.ContentLength == 0)
            {
                return ApiResult<T>.Ok(default, status);
            }

            var data = await response.Content.ReadFromJsonAsync<T>(JsonOptions);
            return ApiResult<T>.Ok(data, status);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Could not reach the RaceDay API at {Url}", url);
            return ApiResult<T>.Fail(0, Unavailable);
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogError(ex, "The RaceDay API timed out for {Url}", url);
            return ApiResult<T>.Fail(0, Unavailable);
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "The RaceDay API returned an unexpected response for {Url}", url);
            return ApiResult<T>.Fail(502, "The RaceDay service returned an unexpected response.");
        }
    }

    private static async Task<string> ReadErrorAsync(HttpResponseMessage response)
    {
        try
        {
            var text = await response.Content.ReadAsStringAsync();

            if (!string.IsNullOrWhiteSpace(text))
            {
                using var document = JsonDocument.Parse(text);
                var root = document.RootElement;

                if (root.ValueKind == JsonValueKind.Object)
                {
                    if (root.TryGetProperty("message", out var message) && message.ValueKind == JsonValueKind.String)
                    {
                        return message.GetString() ?? string.Empty;
                    }

                    if (root.TryGetProperty("errors", out var errors) && errors.ValueKind == JsonValueKind.Object)
                    {
                        var messages = new List<string>();

                        foreach (var property in errors.EnumerateObject())
                        {
                            if (property.Value.ValueKind != JsonValueKind.Array)
                            {
                                continue;
                            }

                            foreach (var item in property.Value.EnumerateArray())
                            {
                                if (item.ValueKind == JsonValueKind.String)
                                {
                                    messages.Add(item.GetString() ?? string.Empty);
                                }
                            }
                        }

                        if (messages.Count > 0)
                        {
                            return string.Join(" ", messages);
                        }
                    }
                }
            }
        }
        catch (JsonException)
        {
            // fall through to the generic wording below
        }

        switch (response.StatusCode)
        {
            case HttpStatusCode.Unauthorized: return "Please sign in to continue.";
            case HttpStatusCode.Forbidden: return "You do not have permission to do that.";
            case HttpStatusCode.NotFound: return "We could not find what you were looking for.";
            case HttpStatusCode.Conflict: return "That conflicts with existing information.";
            default: return "Something went wrong. Please try again.";
        }
    }
}
