namespace RaceDay.Mvc.Services;

/// <summary>
/// The outcome of one call to the RaceDay API. Controllers inspect this instead of catching
/// exceptions, so a stopped API or a validation error becomes a friendly message, never a crash.
/// </summary>
public class ApiResult
{
    public bool Success { get; init; }

    /// <summary>HTTP status code, or 0 when the API could not be reached at all.</summary>
    public int StatusCode { get; init; }

    public string? Error { get; init; }

    public bool IsUnauthorized => StatusCode == 401;

    public bool IsForbidden => StatusCode == 403;

    public bool IsNotFound => StatusCode == 404;

    public bool IsUnavailable => StatusCode == 0 || StatusCode >= 500;

    /// <summary>A message that is safe to show to the user.</summary>
    public string Message => Error ?? "Something went wrong. Please try again.";
}

public class ApiResult<T> : ApiResult
{
    public T? Data { get; init; }

    public static ApiResult<T> Ok(T? data, int statusCode) =>
        new() { Success = true, StatusCode = statusCode, Data = data };

    public static ApiResult<T> Fail(int statusCode, string error) =>
        new() { Success = false, StatusCode = statusCode, Error = error };
}
