using RaceDay.Mvc.Models.Api;

namespace RaceDay.Mvc.Services;

/// <summary>
/// Every operation the MVC site needs from the RaceDay REST API. Controllers depend on this
/// interface, so no controller ever builds an HTTP request or touches the database directly.
/// </summary>
public interface IRaceDayApi
{
    // ----- authentication -----
    Task<ApiResult<LoginResponse>> LoginAsync(string email, string password);
    Task<ApiResult<UserDto>> RegisterAsync(RegisterPayload payload);
    Task LogoutAsync();

    // ----- profile -----
    Task<ApiResult<UserDto>> GetProfileAsync();
    Task<ApiResult<UserDto>> UpdateProfileAsync(string firstName, string lastName, string? phoneNumber);
    Task<ApiResult<UploadResponse>> UploadProfilePictureAsync(IFormFile image);

    // ----- events -----
    Task<ApiResult<List<EventDto>>> GetEventsAsync(string? eventType = null, DateTime? from = null);
    Task<ApiResult<EventDetailDto>> GetEventAsync(int eventId);
    Task<ApiResult<EventDto>> CreateEventAsync(EventPayload payload);
    Task<ApiResult<EventDto>> UpdateEventAsync(int eventId, EventPayload payload);
    Task<ApiResult> DeleteEventAsync(int eventId);
    Task<ApiResult<UploadResponse>> UploadBannerAsync(int eventId, IFormFile image);
    Task<ApiResult<List<EventTypeDto>>> GetEventTypesAsync();

    // ----- categories -----
    Task<ApiResult<List<CategoryDto>>> GetCategoriesAsync(int eventId);
    Task<ApiResult<CategoryDto>> CreateCategoryAsync(int eventId, string name, string? description);
    Task<ApiResult<CategoryDto>> UpdateCategoryAsync(int categoryId, string name, string? description);
    Task<ApiResult> DeleteCategoryAsync(int categoryId);

    // ----- enrolments -----
    Task<ApiResult> EnrolAsync(int eventId, int categoryId);
    Task<ApiResult<List<EnrolmentDto>>> GetMyEnrolmentsAsync();
    Task<ApiResult<List<EnrolmentDto>>> GetEventEnrolmentsAsync(int eventId);
    Task<ApiResult> UpdateEnrolmentStatusAsync(int enrolmentId, string status);

    // ----- results -----
    Task<ApiResult> CaptureResultAsync(int enrolmentId, TimeSpan finishTime, int finishPosition, int totalFinishers);
    Task<ApiResult<List<ResultDto>>> GetMyResultsAsync();
    Task<ApiResult<List<ResultDto>>> GetEventResultsAsync(int eventId);
}
