using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/event-types")]
public class EventTypesController : ControllerBase
{
    private readonly RaceDayDbContext _db;

    public EventTypesController(RaceDayDbContext db)
    {
        _db = db;
    }

    /// <summary>Lists the event types (Run, Walk, Cycle) so clients can build a drop-down.</summary>
    /// <response code="200">All event types, ordered by id.</response>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<EventTypeResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll()
    {
        var types = await _db.EventTypes
            .AsNoTracking()
            .OrderBy(t => t.EventTypeId)
            .Select(t => new EventTypeResponse(t.EventTypeId, t.TypeName))
            .ToListAsync();

        return Ok(types);
    }
}
