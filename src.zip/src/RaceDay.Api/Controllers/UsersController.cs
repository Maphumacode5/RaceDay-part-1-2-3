using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    public UsersController(RaceDayDbContext db) => _db=db;

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var id = HttpContext.Session.GetInt32("UserId");
        if (id is null) return Unauthorized();
        var u = await _db.Users.FindAsync(id.Value);
        return u is null ? Unauthorized() : Ok(new UserResponse(u.UserId,u.FirstName,u.LastName,u.Email,u.Role,u.PhoneNumber,u.ProfilePictureUrl));
    }

    [HttpPut("me")]
    public async Task<IActionResult> Update(UpdateProfileRequest request)
    {
        var id = HttpContext.Session.GetInt32("UserId");
        if (id is null) return Unauthorized();
        var u = await _db.Users.FindAsync(id.Value);
        if (u is null) return Unauthorized();
        u.FirstName=request.FirstName.Trim(); u.LastName=request.LastName.Trim(); u.PhoneNumber=request.PhoneNumber?.Trim();
        await _db.SaveChangesAsync();
        return Ok(new UserResponse(u.UserId,u.FirstName,u.LastName,u.Email,u.Role,u.PhoneNumber,u.ProfilePictureUrl));
    }

    /// <summary>
    /// Uploads or replaces the logged-in user's profile picture in Azure Blob Storage and
    /// saves its public URL on the user.
    /// </summary>
    /// <param name="image">JPEG, PNG, GIF or WebP file, 5 MB maximum.</param>
    /// <response code="200">Picture stored. Returns the new picture URL.</response>
    /// <response code="400">No file, wrong type, too large, or contents are not a real image.</response>
    /// <response code="401">No active session.</response>
    /// <response code="503">Image storage has not been configured.</response>
    [HttpPut("me/profile-picture")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> ProfilePicture(
        IFormFile image,
        [FromServices] IBlobStorageService blobStorage,
        CancellationToken cancellationToken)
    {
        var id = HttpContext.Session.GetInt32("UserId");
        if (id is null) return Unauthorized();

        var user = await _db.Users.FindAsync(new object[] { id.Value }, cancellationToken);
        if (user is null) return Unauthorized();

        var validationError = ImageValidator.Validate(image);
        if (validationError is not null) return BadRequest(new { message = validationError });

        await using (var signatureStream = image.OpenReadStream())
        {
            if (!await ImageValidator.HasValidSignatureAsync(signatureStream, image.ContentType))
            {
                return BadRequest(new { message = "The file contents do not match an allowed image type." });
            }
        }

        try
        {
            string url;

            await using (var content = image.OpenReadStream())
            {
                url = await blobStorage.UploadImageAsync(
                    content, image.ContentType, $"profiles/{user.UserId}", cancellationToken);
            }

            var previousUrl = user.ProfilePictureUrl;
            user.ProfilePictureUrl = url;
            await _db.SaveChangesAsync(cancellationToken);

            await blobStorage.DeleteByUrlAsync(previousUrl, cancellationToken);

            return Ok(new { message = "Profile picture updated.", profilePictureUrl = url });
        }
        catch (BlobStorageNotConfiguredException)
        {
            return StatusCode(
                StatusCodes.Status503ServiceUnavailable,
                new { message = "Image storage is not configured on the server." });
        }
        catch (Azure.RequestFailedException)
        {
            return StatusCode(
                StatusCodes.Status502BadGateway,
                new { message = "Image storage rejected the upload. Please try again." });
        }
    }
}
