
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/events")]
public class EventsController : ControllerBase
{
    private readonly RaceDayDbContext _db;

    public EventsController(RaceDayDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] string? eventType,
        [FromQuery] DateTime? from)
    {
        var query = _db.Events
            .AsNoTracking()
            .Include(e => e.EventType)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(eventType))
        {
            query = query.Where(
                e => e.EventType.TypeName == eventType);
        }

        if (from.HasValue)
        {
            query = query.Where(
                e => e.EventDate >= from.Value);
        }

        var data = await query
            .OrderBy(e => e.EventDate)
            .Select(e => new EventResponse(
                e.EventId,
                e.Name,
                e.Description,
                e.EventDate,
                e.Location,
                e.DistanceKm,
                e.EventType.TypeName,
                e.OrganiserId,
                e.BannerImageUrl))
            .ToListAsync();

        return Ok(data);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var eventItem = await _db.Events
            .AsNoTracking()
            .Include(e => e.EventType)
            .Include(e => e.Categories)
            .SingleOrDefaultAsync(e => e.EventId == id);

        if (eventItem is null)
        {
            return NotFound();
        }

        return Ok(new
        {
            eventItem.EventId,
            eventItem.Name,
            eventItem.Description,
            eventItem.EventDate,
            eventItem.Location,
            eventItem.DistanceKm,
            eventItem.BannerImageUrl,
            EventType = eventItem.EventType.TypeName,
            eventItem.OrganiserId,
            Categories = eventItem.Categories.Select(c =>
                new CategoryResponse(
                    c.CategoryId,
                    c.EventId,
                    c.Name,
                    c.Description))
        });
    }

    [HttpPost]
    public async Task<IActionResult> Create(EventRequest request)
    {
        if (!IsRole("Organiser"))
        {
            return Forbid();
        }

        var eventTypeExists = await _db.EventTypes
            .AnyAsync(x => x.EventTypeId == request.EventTypeId);

        if (!eventTypeExists)
        {
            return BadRequest(
                new { message = "Invalid event type." });
        }

        var eventItem = new Event
        {
            OrganiserId = UserId(),
            EventTypeId = request.EventTypeId,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            EventDate = request.EventDate,
            Location = request.Location.Trim(),
            DistanceKm = request.DistanceKm
        };

        _db.Events.Add(eventItem);
        await _db.SaveChangesAsync();

        await _db.Entry(eventItem)
            .Reference(e => e.EventType)
            .LoadAsync();

        return CreatedAtAction(
            nameof(Get),
            new { id = eventItem.EventId },
            new EventResponse(
                eventItem.EventId,
                eventItem.Name,
                eventItem.Description,
                eventItem.EventDate,
                eventItem.Location,
                eventItem.DistanceKm,
                eventItem.EventType.TypeName,
                eventItem.OrganiserId,
                eventItem.BannerImageUrl));
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(
        int id,
        EventRequest request)
    {
        if (!IsRole("Organiser"))
        {
            return Forbid();
        }

        var eventItem = await _db.Events
            .Include(e => e.EventType)
            .SingleOrDefaultAsync(e => e.EventId == id);

        if (eventItem is null)
        {
            return NotFound();
        }

        if (eventItem.OrganiserId != UserId())
        {
            return Forbid();
        }

        var eventTypeExists = await _db.EventTypes
            .AnyAsync(x => x.EventTypeId == request.EventTypeId);

        if (!eventTypeExists)
        {
            return BadRequest(
                new { message = "Invalid event type." });
        }

        eventItem.Name = request.Name.Trim();
        eventItem.Description = request.Description?.Trim();
        eventItem.EventDate = request.EventDate;
        eventItem.Location = request.Location.Trim();
        eventItem.DistanceKm = request.DistanceKm;
        eventItem.EventTypeId = request.EventTypeId;

        await _db.SaveChangesAsync();

        await _db.Entry(eventItem)
            .Reference(e => e.EventType)
            .LoadAsync();

        return Ok(new EventResponse(
            eventItem.EventId,
            eventItem.Name,
            eventItem.Description,
            eventItem.EventDate,
            eventItem.Location,
            eventItem.DistanceKm,
            eventItem.EventType.TypeName,
            eventItem.OrganiserId,
            eventItem.BannerImageUrl));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        if (!IsRole("Organiser"))
        {
            return Forbid();
        }

        var eventItem = await _db.Events.FindAsync(id);

        if (eventItem is null)
        {
            return NotFound();
        }

        if (eventItem.OrganiserId != UserId())
        {
            return Forbid();
        }

        try
        {
            _db.Events.Remove(eventItem);
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            // Enrolments reference the event (ON DELETE RESTRICT), so it cannot be removed.
            return Conflict(new { message = "This event already has enrolments, so it cannot be deleted." });
        }

        return NoContent();
    }

    /// <summary>
    /// Uploads or replaces the event banner. The image is validated and stored in Azure Blob
    /// Storage; the resulting public URL is saved on the event.
    /// </summary>
    /// <param name="id">The event id.</param>
    /// <param name="image">JPEG, PNG, GIF or WebP file, 5 MB maximum.</param>
    /// <response code="200">Banner stored. Returns the new banner URL.</response>
    /// <response code="400">No file, wrong type, too large, or contents are not a real image.</response>
    /// <response code="403">Caller is not the Organiser who owns the event.</response>
    /// <response code="404">Event does not exist.</response>
    /// <response code="503">Image storage has not been configured.</response>
    [HttpPost("{id:int}/banner")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> Banner(
        int id,
        IFormFile image,
        [FromServices] IBlobStorageService blobStorage,
        CancellationToken cancellationToken)
    {
        if (!IsRole("Organiser"))
        {
            return Forbid();
        }

        var eventItem = await _db.Events.FindAsync(new object[] { id }, cancellationToken);

        if (eventItem is null)
        {
            return NotFound();
        }

        if (eventItem.OrganiserId != UserId())
        {
            return Forbid();
        }

        var validationError = ImageValidator.Validate(image);

        if (validationError is not null)
        {
            return BadRequest(new { message = validationError });
        }

        await using (var signatureStream = image.OpenReadStream())
        {
            if (!await ImageValidator.HasValidSignatureAsync(signatureStream, image.ContentType))
            {
                return BadRequest(new { message = "The file contents do not match an allowed image type." });
            }
        }

        try
        {
            string url;

            await using (var content = image.OpenReadStream())
            {
                url = await blobStorage.UploadImageAsync(
                    content, image.ContentType, $"events/{id}", cancellationToken);
            }

            var previousUrl = eventItem.BannerImageUrl;
            eventItem.BannerImageUrl = url;
            await _db.SaveChangesAsync(cancellationToken);

            await blobStorage.DeleteByUrlAsync(previousUrl, cancellationToken);

            return Ok(new { message = "Banner uploaded successfully.", bannerImageUrl = url });
        }
        catch (BlobStorageNotConfiguredException)
        {
            return StatusCode(
                StatusCodes.Status503ServiceUnavailable,
                new { message = "Image storage is not configured on the server." });
        }
        catch (Azure.RequestFailedException)
        {
            return StatusCode(
                StatusCodes.Status502BadGateway,
                new { message = "Image storage rejected the upload. Please try again." });
        }
    }

    private bool IsRole(string role)
    {
        return HttpContext.Session.GetString("Role") == role
            && HttpContext.Session.GetInt32("UserId") is not null;
    }

    private int UserId()
    {
        return HttpContext.Session.GetInt32("UserId")!.Value;
    }
}
