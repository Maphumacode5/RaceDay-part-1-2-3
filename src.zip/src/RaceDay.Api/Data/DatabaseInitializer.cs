using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Data;

/// <summary>
/// Optional start-up helper used for Docker / demo environments.
/// <list type="bullet">
/// <item><c>Database:AutoMigrate</c> applies the EF Core migrations to an empty SQL Server.</item>
/// <item><c>Database:SeedDemoData</c> adds demo accounts, events and a completed race - only when the Users table is empty.</item>
/// </list>
/// Both are off by default, so running against the database created by the Part 1 SQL script is unchanged.
/// </summary>
public static class DatabaseInitializer
{
    public const string DemoPassword = "RaceDay#2026";
    public const string DemoOrganiserEmail = "organiser@raceday.co.za";
    public const string DemoParticipantEmail = "participant@raceday.co.za";

    public static async Task InitialiseAsync(IServiceProvider services, IConfiguration configuration)
    {
        var autoMigrate = configuration.GetValue<bool>("Database:AutoMigrate");
        var seedDemoData = configuration.GetValue<bool>("Database:SeedDemoData");

        if (!autoMigrate && !seedDemoData)
        {
            return;
        }

        using var scope = services.CreateScope();
        var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("DatabaseInitializer");
        var db = scope.ServiceProvider.GetRequiredService<RaceDayDbContext>();
        var passwords = scope.ServiceProvider.GetRequiredService<IPasswordService>();

        const int maxAttempts = 15;

        for (var attempt = 1; ; attempt++)
        {
            try
            {
                if (autoMigrate)
                {
                    await db.Database.MigrateAsync();
                }

                await EnsureEventTypesAsync(db);

                if (seedDemoData)
                {
                    await SeedDemoDataAsync(db, passwords);
                }

                logger.LogInformation("Database initialised.");
                return;
            }
            catch (Exception ex) when (attempt < maxAttempts)
            {
                // SQL Server in Docker can take a while to accept connections.
                logger.LogWarning(ex, "Database not ready (attempt {Attempt}/{Max}). Retrying in 4 seconds...", attempt, maxAttempts);
                await Task.Delay(TimeSpan.FromSeconds(4));
            }
        }
    }

    /// <summary>Makes sure the Run / Walk / Cycle lookup rows exist. Safe to run repeatedly.</summary>
    public static async Task EnsureEventTypesAsync(RaceDayDbContext db)
    {
        foreach (var name in new[] { "Run", "Walk", "Cycle" })
        {
            if (!await db.EventTypes.AnyAsync(t => t.TypeName == name))
            {
                db.EventTypes.Add(new EventType { TypeName = name });
            }
        }

        await db.SaveChangesAsync();
    }

    /// <summary>Seeds demo data into an empty database. Does nothing if any user already exists.</summary>
    public static async Task SeedDemoDataAsync(RaceDayDbContext db, IPasswordService passwords)
    {
        if (await db.Users.AnyAsync())
        {
            return;
        }

        var organiser = new User
        {
            FirstName = "Thandi",
            LastName = "Mokoena",
            Email = DemoOrganiserEmail,
            Role = "Organiser",
            PhoneNumber = "0821234567",
            PasswordHash = passwords.Hash(DemoPassword),
            CreatedAt = DateTime.UtcNow
        };

        var participant = new User
        {
            FirstName = "Sipho",
            LastName = "Dlamini",
            Email = DemoParticipantEmail,
            Role = "Participant",
            PhoneNumber = "0837654321",
            PasswordHash = passwords.Hash(DemoPassword),
            CreatedAt = DateTime.UtcNow
        };

        db.Users.AddRange(organiser, participant);
        await db.SaveChangesAsync();

        var run = await db.EventTypes.SingleAsync(t => t.TypeName == "Run");
        var walk = await db.EventTypes.SingleAsync(t => t.TypeName == "Walk");
        var cycle = await db.EventTypes.SingleAsync(t => t.TypeName == "Cycle");

        var today = DateTime.Today;

        var springRun = new Event
        {
            OrganiserId = organiser.UserId,
            EventTypeId = run.EventTypeId,
            Name = "Pretoria Spring 10K",
            Description = "A fast, flat 10km road race through the Pretoria East suburbs with water points every 2.5km.",
            EventDate = today.AddDays(30).AddHours(6),
            Location = "Menlyn Park, Pretoria",
            DistanceKm = 10m,
            CreatedAt = DateTime.UtcNow
        };

        var charityWalk = new Event
        {
            OrganiserId = organiser.UserId,
            EventTypeId = walk.EventTypeId,
            Name = "Limpopo Charity Walk",
            Description = "A family-friendly fun walk raising funds for local schools. Prams and dogs on leads welcome.",
            EventDate = today.AddDays(14).AddHours(7),
            Location = "Polokwane, Limpopo",
            DistanceKm = 5m,
            CreatedAt = DateTime.UtcNow
        };

        var highveldClassic = new Event
        {
            OrganiserId = organiser.UserId,
            EventTypeId = cycle.EventTypeId,
            Name = "Highveld Cycle Classic",
            Description = "A scenic road cycling event across the Mpumalanga highveld. This race has already taken place.",
            EventDate = today.AddDays(-21).AddHours(6).AddMinutes(30),
            Location = "Middelburg, Mpumalanga",
            DistanceKm = 94m,
            CreatedAt = DateTime.UtcNow
        };

        db.Events.AddRange(springRun, charityWalk, highveldClassic);
        await db.SaveChangesAsync();

        var run10 = new Category { EventId = springRun.EventId, Name = "10km Open", Description = "Open to all runners 18 and over." };
        var runJunior = new Category { EventId = springRun.EventId, Name = "Under 20", Description = "Runners under 20 on race day." };
        var walk5 = new Category { EventId = charityWalk.EventId, Name = "5km Fun Walk", Description = "Walk at your own pace." };
        var walkFamily = new Category { EventId = charityWalk.EventId, Name = "Family Group", Description = "Groups of three or more." };
        var cycle94 = new Category { EventId = highveldClassic.EventId, Name = "94km Open", Description = "Full distance, all ages." };
        var cycleVets = new Category { EventId = highveldClassic.EventId, Name = "Veterans 50+", Description = "Riders aged 50 and over." };

        db.Categories.AddRange(run10, runJunior, walk5, walkFamily, cycle94, cycleVets);
        await db.SaveChangesAsync();

        var pastEnrolment = new Enrolment
        {
            ParticipantId = participant.UserId,
            EventId = highveldClassic.EventId,
            CategoryId = cycle94.CategoryId,
            EnrolmentDate = today.AddDays(-45),
            Status = "Confirmed"
        };

        var pendingEnrolment = new Enrolment
        {
            ParticipantId = participant.UserId,
            EventId = charityWalk.EventId,
            CategoryId = walk5.CategoryId,
            EnrolmentDate = today.AddDays(-2),
            Status = "Pending"
        };

        db.Enrolments.AddRange(pastEnrolment, pendingEnrolment);
        await db.SaveChangesAsync();

        db.Results.Add(new Result
        {
            EnrolmentId = pastEnrolment.EnrolmentId,
            FinishTime = new TimeSpan(2, 41, 13),
            FinishPosition = 47,
            TotalFinishers = 312,
            CapturedAt = today.AddDays(-20)
        });

        await db.SaveChangesAsync();
    }
}
