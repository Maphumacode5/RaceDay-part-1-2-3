using Microsoft.AspNetCore.Http;

namespace RaceDay.Api.Services;

/// <summary>
/// Server-side checks for uploaded images: size, declared content type and the real
/// file signature ("magic bytes"), so a renamed .exe cannot be stored as a picture.
/// </summary>
public static class ImageValidator
{
    public const long MaxBytes = 5 * 1024 * 1024;

    private static readonly Dictionary<string, string> Extensions =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["image/jpeg"] = ".jpg",
            ["image/png"] = ".png",
            ["image/gif"] = ".gif",
            ["image/webp"] = ".webp"
        };

    public static bool IsAllowedContentType(string? contentType) =>
        !string.IsNullOrWhiteSpace(contentType) && Extensions.ContainsKey(contentType);

    public static string ExtensionFor(string contentType) =>
        Extensions.TryGetValue(contentType, out var extension)
            ? extension
            : throw new ArgumentException("Unsupported image type.", nameof(contentType));

    /// <summary>Returns null when the file is acceptable, otherwise a user-friendly message.</summary>
    public static string? Validate(IFormFile? file)
    {
        if (file is null || file.Length == 0)
        {
            return "An image file is required.";
        }

        if (file.Length > MaxBytes)
        {
            return "The image must be 5 MB or smaller.";
        }

        if (!IsAllowedContentType(file.ContentType))
        {
            return "Only JPEG, PNG, GIF or WebP images are allowed.";
        }

        return null;
    }

    /// <summary>Checks the first bytes of the stream against the declared content type.</summary>
    public static async Task<bool> HasValidSignatureAsync(Stream stream, string contentType)
    {
        var header = new byte[12];
        var read = 0;
        while (read < header.Length)
        {
            var count = await stream.ReadAsync(header.AsMemory(read, header.Length - read));
            if (count == 0)
            {
                break;
            }

            read += count;
        }

        if (read < header.Length)
        {
            return false;
        }

        return contentType.ToLowerInvariant() switch
        {
            "image/jpeg" => header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF,
            "image/png" => header[0] == 0x89 && header[1] == 0x50 && header[2] == 0x4E && header[3] == 0x47
                           && header[4] == 0x0D && header[5] == 0x0A && header[6] == 0x1A && header[7] == 0x0A,
            "image/gif" => header[0] == 0x47 && header[1] == 0x49 && header[2] == 0x46 && header[3] == 0x38,
            "image/webp" => header[0] == 0x52 && header[1] == 0x49 && header[2] == 0x46 && header[3] == 0x46
                            && header[8] == 0x57 && header[9] == 0x45 && header[10] == 0x42 && header[11] == 0x50,
            _ => false
        };
    }
}
