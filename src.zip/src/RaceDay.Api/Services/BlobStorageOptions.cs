namespace RaceDay.Api.Services;

/// <summary>
/// Settings for Azure Blob Storage. Bound from the "BlobStorage" configuration section.
/// The connection string must never be committed - use user-secrets locally and
/// environment variables / app settings when deployed.
/// </summary>
public class BlobStorageOptions
{
    public const string SectionName = "BlobStorage";

    /// <summary>Azure Storage connection string (or Azurite for local development).</summary>
    public string? ConnectionString { get; set; }

    /// <summary>Container that holds event banners and profile pictures.</summary>
    public string ContainerName { get; set; } = "raceday-images";

    /// <summary>
    /// Optional. When set, the URL returned to clients is built from this base address
    /// instead of the storage endpoint (needed when the browser reaches storage through
    /// a different host name than the API does, e.g. Azurite inside Docker, or a CDN).
    /// </summary>
    public string? PublicBaseUrl { get; set; }
}
