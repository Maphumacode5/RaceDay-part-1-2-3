using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Options;

namespace RaceDay.Api.Services;

/// <summary>
/// Stores event banners and profile pictures in an Azure Blob Storage container.
/// Registered as a singleton so the container client is created once.
/// </summary>
public sealed class BlobStorageService : IBlobStorageService
{
    private readonly BlobStorageOptions _options;
    private readonly ILogger<BlobStorageService> _logger;
    private readonly SemaphoreSlim _initLock = new(1, 1);
    private BlobContainerClient? _container;

    public BlobStorageService(IOptions<BlobStorageOptions> options, ILogger<BlobStorageService> logger)
    {
        _options = options.Value;
        _logger = logger;
    }

    public async Task<string> UploadImageAsync(
        Stream content, string contentType, string folder, CancellationToken cancellationToken = default)
    {
        var container = await GetContainerAsync(cancellationToken);

        var blobName = $"{folder.Trim('/')}/{Guid.NewGuid():N}{ImageValidator.ExtensionFor(contentType)}";
        var blob = container.GetBlobClient(blobName);

        await blob.UploadAsync(
            content,
            new BlobUploadOptions { HttpHeaders = new BlobHttpHeaders { ContentType = contentType } },
            cancellationToken);

        return BuildPublicUrl(container, blobName, blob.Uri);
    }

    public async Task DeleteByUrlAsync(string? url, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(url) || string.IsNullOrWhiteSpace(_options.ConnectionString))
        {
            return;
        }

        try
        {
            var container = await GetContainerAsync(cancellationToken);

            foreach (var prefix in KnownPrefixes(container))
            {
                if (url.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    var blobName = Uri.UnescapeDataString(url[prefix.Length..]);
                    await container.DeleteBlobIfExistsAsync(blobName, cancellationToken: cancellationToken);
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            // Cleaning up an old image must never break the request that replaced it.
            _logger.LogWarning(ex, "Could not delete previous blob {Url}", url);
        }
    }

    private async Task<BlobContainerClient> GetContainerAsync(CancellationToken cancellationToken)
    {
        if (_container is not null)
        {
            return _container;
        }

        if (string.IsNullOrWhiteSpace(_options.ConnectionString))
        {
            throw new BlobStorageNotConfiguredException();
        }

        await _initLock.WaitAsync(cancellationToken);
        try
        {
            if (_container is null)
            {
                var serviceClient = new BlobServiceClient(_options.ConnectionString);
                var container = serviceClient.GetBlobContainerClient(_options.ContainerName);

                // Public read access at blob level lets the MVC site show images with a plain <img> tag.
                await container.CreateIfNotExistsAsync(PublicAccessType.Blob, cancellationToken: cancellationToken);
                _container = container;
            }

            return _container;
        }
        finally
        {
            _initLock.Release();
        }
    }

    private string BuildPublicUrl(BlobContainerClient container, string blobName, Uri blobUri)
    {
        if (!string.IsNullOrWhiteSpace(_options.PublicBaseUrl))
        {
            return $"{_options.PublicBaseUrl.TrimEnd('/')}/{container.Name}/{blobName}";
        }

        return blobUri.ToString();
    }

    private IEnumerable<string> KnownPrefixes(BlobContainerClient container)
    {
        if (!string.IsNullOrWhiteSpace(_options.PublicBaseUrl))
        {
            yield return $"{_options.PublicBaseUrl.TrimEnd('/')}/{container.Name}/";
        }

        yield return container.Uri.ToString().TrimEnd('/') + "/";
    }
}
