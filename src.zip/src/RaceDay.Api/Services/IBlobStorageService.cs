namespace RaceDay.Api.Services;

/// <summary>Abstraction over Azure Blob Storage so controllers can be unit tested.</summary>
public interface IBlobStorageService
{
    /// <summary>Uploads an image and returns its public URL.</summary>
    /// <param name="content">The image bytes.</param>
    /// <param name="contentType">A validated image content type, e.g. image/png.</param>
    /// <param name="folder">Virtual folder inside the container, e.g. events/12.</param>
    Task<string> UploadImageAsync(Stream content, string contentType, string folder, CancellationToken cancellationToken = default);

    /// <summary>Best-effort removal of a previously uploaded image. Never throws.</summary>
    Task DeleteByUrlAsync(string? url, CancellationToken cancellationToken = default);
}

/// <summary>Raised when image storage has not been configured on the server.</summary>
public class BlobStorageNotConfiguredException : Exception
{
    public BlobStorageNotConfiguredException()
        : base("Azure Blob Storage is not configured. Set BlobStorage:ConnectionString.")
    {
    }
}
