using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Tests;

/// <summary>Image uploads for event banners and profile pictures, using a fake in place of Azure.</summary>
public class BlobUploadTests
{
    private sealed class FakeBlobStorage : IBlobStorageService
    {
        public List<string> Deleted { get; } = new();

        public int Uploads { get; private set; }

        public bool NotConfigured { get; set; }

        public Task<string> UploadImageAsync(
            Stream content, string contentType, string folder, CancellationToken cancellationToken = default)
        {
            if (NotConfigured)
            {
                throw new BlobStorageNotConfiguredException();
            }

            Uploads++;
            return Task.FromResult("https://fake.blob/" + folder + "/test.png");
        }

        public Task DeleteByUrlAsync(string? url, CancellationToken cancellationToken = default)
        {
            if (url is not null)
            {
                Deleted.Add(url);
            }

            return Task.CompletedTask;
        }
    }

    private static byte[] PngBytes()
    {
        var bytes = new byte[32];
        new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A }.CopyTo(bytes, 0);
        return bytes;
    }

    private static FormFile File(byte[] bytes, string contentType) =>
        new(new MemoryStream(bytes), 0, bytes.Length, "image", "banner.png")
        {
            Headers = new HeaderDictionary(),
            ContentType = contentType
        };

    private static async Task SeedAsync(RaceDayDbContext db, string? existingBanner = null)
    {
        db.Users.AddRange(
            new User { UserId = 1, FirstName = "Org", LastName = "One", Email = "o@x.com", PasswordHash = "x", Role = "Organiser" },
            new User { UserId = 2, FirstName = "Part", LastName = "One", Email = "p@x.com", PasswordHash = "x", Role = "Participant" },
            new User { UserId = 3, FirstName = "Org", LastName = "Two", Email = "o2@x.com", PasswordHash = "x", Role = "Organiser" });
        db.EventTypes.Add(new EventType { EventTypeId = 1, TypeName = "Run" });
        db.Events.Add(new Event
        {
            EventId = 1, OrganiserId = 1, EventTypeId = 1, Name = "Race", EventDate = DateTime.UtcNow,
            Location = "JHB", DistanceKm = 10, BannerImageUrl = existingBanner
        });
        await db.SaveChangesAsync();
    }

    private static EventsController EventsAs(RaceDayDbContext db, int userId, string? role)
    {
        var controller = new EventsController(db);
        controller.ControllerContext = new() { HttpContext = TestInfrastructure.Context(userId, role) };
        return controller;
    }

    [Fact]
    public async Task Banner_Participant_IsForbidden()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var blob = new FakeBlobStorage();

        var result = await EventsAs(db, 2, "Participant").Banner(1, File(PngBytes(), "image/png"), blob, CancellationToken.None);

        Assert.IsType<ForbidResult>(result);
        Assert.Equal(0, blob.Uploads);
    }

    [Fact]
    public async Task Banner_OrganiserWhoDoesNotOwnEvent_IsForbidden()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var blob = new FakeBlobStorage();

        var result = await EventsAs(db, 3, "Organiser").Banner(1, File(PngBytes(), "image/png"), blob, CancellationToken.None);

        Assert.IsType<ForbidResult>(result);
        Assert.Equal(0, blob.Uploads);
    }

    [Fact]
    public async Task Banner_MissingEvent_ReturnsNotFound()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);

        var result = await EventsAs(db, 1, "Organiser").Banner(99, File(PngBytes(), "image/png"), new FakeBlobStorage(), CancellationToken.None);

        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task Banner_OwnerWithValidImage_SavesUrlOnEvent()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var blob = new FakeBlobStorage();

        var result = await EventsAs(db, 1, "Organiser").Banner(1, File(PngBytes(), "image/png"), blob, CancellationToken.None);

        Assert.IsType<OkObjectResult>(result);
        Assert.Equal(1, blob.Uploads);
        Assert.Equal("https://fake.blob/events/1/test.png", db.Events.Single().BannerImageUrl);
    }

    [Fact]
    public async Task Banner_ReplacingExistingImage_DeletesOldBlob()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db, existingBanner: "https://fake.blob/events/1/old.png");
        var blob = new FakeBlobStorage();

        await EventsAs(db, 1, "Organiser").Banner(1, File(PngBytes(), "image/png"), blob, CancellationToken.None);

        Assert.Contains("https://fake.blob/events/1/old.png", blob.Deleted);
    }

    [Fact]
    public async Task Banner_WrongContentType_ReturnsBadRequest()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var blob = new FakeBlobStorage();

        var result = await EventsAs(db, 1, "Organiser").Banner(1, File(PngBytes(), "text/plain"), blob, CancellationToken.None);

        Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(0, blob.Uploads);
    }

    [Fact]
    public async Task Banner_FileThatIsNotReallyAnImage_ReturnsBadRequest()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var blob = new FakeBlobStorage();
        var notAnImage = System.Text.Encoding.ASCII.GetBytes("MZ this is an executable pretending to be a png");

        var result = await EventsAs(db, 1, "Organiser").Banner(1, File(notAnImage, "image/png"), blob, CancellationToken.None);

        Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(0, blob.Uploads);
    }

    [Fact]
    public async Task Banner_StorageNotConfigured_Returns503()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var blob = new FakeBlobStorage { NotConfigured = true };

        var result = await EventsAs(db, 1, "Organiser").Banner(1, File(PngBytes(), "image/png"), blob, CancellationToken.None);

        var objectResult = Assert.IsType<ObjectResult>(result);
        Assert.Equal(StatusCodes.Status503ServiceUnavailable, objectResult.StatusCode);
        Assert.Null(db.Events.Single().BannerImageUrl);
    }

    [Fact]
    public async Task ProfilePicture_Unauthenticated_ReturnsUnauthorized()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var controller = new UsersController(db);
        controller.ControllerContext = new() { HttpContext = TestInfrastructure.Context() };

        var result = await controller.ProfilePicture(File(PngBytes(), "image/png"), new FakeBlobStorage(), CancellationToken.None);

        Assert.IsType<UnauthorizedResult>(result);
    }

    [Fact]
    public async Task ProfilePicture_Authenticated_SavesUrlOnUser()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await SeedAsync(db);
        var blob = new FakeBlobStorage();
        var controller = new UsersController(db);
        controller.ControllerContext = new() { HttpContext = TestInfrastructure.Context(2, "Participant") };

        var result = await controller.ProfilePicture(File(PngBytes(), "image/png"), blob, CancellationToken.None);

        Assert.IsType<OkObjectResult>(result);
        Assert.Equal("https://fake.blob/profiles/2/test.png", db.Users.Single(u => u.UserId == 2).ProfilePictureUrl);
    }
}
