using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Controllers;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Tests;

public class EventTypesAndSeedTests
{
    [Fact]
    public async Task EventTypes_ReturnsRunWalkCycle()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        await DatabaseInitializer.EnsureEventTypesAsync(db);

        var result = await new EventTypesController(db).GetAll();

        var ok = Assert.IsType<OkObjectResult>(result);
        var types = Assert.IsAssignableFrom<IEnumerable<EventTypeResponse>>(ok.Value).ToList();
        Assert.Equal(3, types.Count);
        Assert.Contains(types, t => t.TypeName == "Run");
        Assert.Contains(types, t => t.TypeName == "Walk");
        Assert.Contains(types, t => t.TypeName == "Cycle");
    }

    [Fact]
    public async Task EnsureEventTypes_RunTwice_DoesNotDuplicate()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());

        await DatabaseInitializer.EnsureEventTypesAsync(db);
        await DatabaseInitializer.EnsureEventTypesAsync(db);

        Assert.Equal(3, db.EventTypes.Count());
    }

    [Fact]
    public async Task SeedDemoData_CreatesAccountsEventsAndOneResult()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        var passwords = new PasswordService();
        await DatabaseInitializer.EnsureEventTypesAsync(db);

        await DatabaseInitializer.SeedDemoDataAsync(db, passwords);

        Assert.Equal(2, db.Users.Count());
        Assert.Equal(3, db.Events.Count());
        Assert.Equal(6, db.Categories.Count());
        Assert.Equal(2, db.Enrolments.Count());
        Assert.Single(db.Results);
    }

    [Fact]
    public async Task SeedDemoData_StoresHashedPasswordsThatVerify()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        var passwords = new PasswordService();
        await DatabaseInitializer.EnsureEventTypesAsync(db);

        await DatabaseInitializer.SeedDemoDataAsync(db, passwords);

        foreach (var user in db.Users.ToList())
        {
            Assert.NotEqual(DatabaseInitializer.DemoPassword, user.PasswordHash);
            Assert.True(passwords.Verify(DatabaseInitializer.DemoPassword, user.PasswordHash));
        }
    }

    [Fact]
    public async Task SeedDemoData_WhenUsersAlreadyExist_DoesNothing()
    {
        await using var db = TestInfrastructure.CreateDb(Guid.NewGuid().ToString());
        var passwords = new PasswordService();
        await DatabaseInitializer.EnsureEventTypesAsync(db);
        db.Users.Add(new RaceDay.Api.Models.User
        {
            FirstName = "Existing", LastName = "User", Email = "e@x.com", PasswordHash = "x", Role = "Participant"
        });
        await db.SaveChangesAsync();

        await DatabaseInitializer.SeedDemoDataAsync(db, passwords);

        Assert.Single(db.Users);
        Assert.Empty(db.Events);
    }
}
