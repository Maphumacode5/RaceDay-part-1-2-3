using Microsoft.AspNetCore.Http;
using RaceDay.Api.Services;

namespace RaceDay.Api.Tests;

public class ImageValidatorTests
{
    private static FormFile File(byte[] bytes, string contentType) =>
        new(new MemoryStream(bytes), 0, bytes.Length, "image", "upload")
        {
            Headers = new HeaderDictionary(),
            ContentType = contentType
        };

    private static byte[] Pad(params byte[] start)
    {
        var bytes = new byte[16];
        Array.Copy(start, bytes, start.Length);
        return bytes;
    }

    [Fact]
    public void Validate_NullFile_ReturnsMessage()
    {
        Assert.NotNull(ImageValidator.Validate(null));
    }

    [Fact]
    public void Validate_EmptyFile_ReturnsMessage()
    {
        Assert.NotNull(ImageValidator.Validate(File(Array.Empty<byte>(), "image/png")));
    }

    [Fact]
    public void Validate_TooLarge_MentionsLimit()
    {
        var big = new FormFile(Stream.Null, 0, ImageValidator.MaxBytes + 1, "image", "big.png")
        {
            Headers = new HeaderDictionary(),
            ContentType = "image/png"
        };

        var message = ImageValidator.Validate(big);

        Assert.NotNull(message);
        Assert.Contains("5 MB", message);
    }

    [Fact]
    public void Validate_WrongContentType_ReturnsMessage()
    {
        Assert.NotNull(ImageValidator.Validate(File(Pad(1, 2, 3), "text/plain")));
    }

    [Fact]
    public void Validate_PngUnderLimit_ReturnsNull()
    {
        Assert.Null(ImageValidator.Validate(File(Pad(0x89, 0x50, 0x4E, 0x47), "image/png")));
    }

    [Theory]
    [InlineData("image/png", ".png")]
    [InlineData("image/jpeg", ".jpg")]
    [InlineData("image/gif", ".gif")]
    [InlineData("image/webp", ".webp")]
    public void ExtensionFor_KnownTypes(string contentType, string expected)
    {
        Assert.Equal(expected, ImageValidator.ExtensionFor(contentType));
    }

    [Fact]
    public void ExtensionFor_UnknownType_Throws()
    {
        Assert.Throws<ArgumentException>(() => ImageValidator.ExtensionFor("application/pdf"));
    }

    [Fact]
    public async Task Signature_RealPng_IsAccepted()
    {
        var bytes = Pad(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A);
        Assert.True(await ImageValidator.HasValidSignatureAsync(new MemoryStream(bytes), "image/png"));
    }

    [Fact]
    public async Task Signature_RealJpeg_IsAccepted()
    {
        var bytes = Pad(0xFF, 0xD8, 0xFF, 0xE0);
        Assert.True(await ImageValidator.HasValidSignatureAsync(new MemoryStream(bytes), "image/jpeg"));
    }

    [Fact]
    public async Task Signature_RealGif_IsAccepted()
    {
        var bytes = Pad(0x47, 0x49, 0x46, 0x38, 0x39, 0x61);
        Assert.True(await ImageValidator.HasValidSignatureAsync(new MemoryStream(bytes), "image/gif"));
    }

    [Fact]
    public async Task Signature_RealWebp_IsAccepted()
    {
        var bytes = Pad(0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50);
        Assert.True(await ImageValidator.HasValidSignatureAsync(new MemoryStream(bytes), "image/webp"));
    }

    [Fact]
    public async Task Signature_PngBytesDeclaredAsJpeg_IsRejected()
    {
        var bytes = Pad(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A);
        Assert.False(await ImageValidator.HasValidSignatureAsync(new MemoryStream(bytes), "image/jpeg"));
    }

    [Fact]
    public async Task Signature_PlainText_IsRejected()
    {
        var bytes = System.Text.Encoding.ASCII.GetBytes("this is definitely not an image");
        Assert.False(await ImageValidator.HasValidSignatureAsync(new MemoryStream(bytes), "image/png"));
    }

    [Fact]
    public async Task Signature_TooShort_IsRejected()
    {
        Assert.False(await ImageValidator.HasValidSignatureAsync(new MemoryStream(new byte[] { 0x89, 0x50 }), "image/png"));
    }
}
