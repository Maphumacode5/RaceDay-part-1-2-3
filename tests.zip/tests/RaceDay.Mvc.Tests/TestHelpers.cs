using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging.Abstractions;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Tests;

/// <summary>In-memory ISession so tests can exercise code that reads and writes the MVC session.</summary>
public sealed class FakeSession : ISession
{
    private readonly Dictionary<string, byte[]> _data = new();

    public IEnumerable<string> Keys => _data.Keys;

    public string Id => "test-session";

    public bool IsAvailable => true;

    public void Clear() => _data.Clear();

    public Task CommitAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;

    public Task LoadAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;

    public void Remove(string key) => _data.Remove(key);

    public void Set(string key, byte[] value) => _data[key] = value;

    public bool TryGetValue(string key, [NotNullWhen(true)] out byte[]? value) => _data.TryGetValue(key, out value);
}

/// <summary>Stands in for the RaceDay API: returns canned responses and records what was sent.</summary>
public sealed class StubHandler : HttpMessageHandler
{
    private readonly Func<HttpRequestMessage, HttpResponseMessage> _responder;

    public StubHandler(Func<HttpRequestMessage, HttpResponseMessage> responder)
    {
        _responder = responder;
    }

    public string? LastCookie { get; private set; }

    public string? LastPathAndQuery { get; private set; }

    public string? LastMethod { get; private set; }

    public string? LastBody { get; private set; }

    public int CallCount { get; private set; }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
    {
        CallCount++;
        LastMethod = request.Method.Method;
        LastPathAndQuery = request.RequestUri?.PathAndQuery;
        LastCookie = request.Headers.TryGetValues("Cookie", out var cookies) ? string.Join("; ", cookies) : null;
        LastBody = request.Content is null ? null : await request.Content.ReadAsStringAsync(cancellationToken);

        return _responder(request);
    }
}

public static class TestHelpers
{
    public static HttpResponseMessage Json(HttpStatusCode status, string json) =>
        new(status) { Content = new StringContent(json, Encoding.UTF8, "application/json") };

    public static (RaceDayApi Api, FakeSession Session, StubHandler Handler) CreateApi(
        Func<HttpRequestMessage, HttpResponseMessage> responder)
    {
        var handler = new StubHandler(responder);
        var http = new HttpClient(handler) { BaseAddress = new Uri("http://api.test/") };
        var session = new FakeSession();
        var context = new DefaultHttpContext { Session = session };
        var accessor = new HttpContextAccessor { HttpContext = context };

        return (new RaceDayApi(http, accessor, NullLogger<RaceDayApi>.Instance), session, handler);
    }
}
