using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using RaceDay.Mvc.Infrastructure;

namespace RaceDay.Mvc.Tests;

public class RequireLoginAttributeTests
{
    private static ActionExecutingContext MakeContext(int userId = 0, string? role = null, string method = "GET")
    {
        var http = new DefaultHttpContext { Session = new FakeSession() };
        http.Request.Method = method;
        http.Request.Path = "/Participant/MyResults";

        if (userId > 0)
        {
            http.Session.SetInt32(SessionKeys.UserId, userId);
            http.Session.SetString(SessionKeys.Role, role ?? string.Empty);
            http.Session.SetString(SessionKeys.DisplayName, "Test User");
        }

        var actionContext = new ActionContext(http, new RouteData(), new ActionDescriptor());

        return new ActionExecutingContext(
            actionContext,
            new List<IFilterMetadata>(),
            new Dictionary<string, object?>(),
            new object());
    }

    [Fact]
    public void Anonymous_IsRedirectedToLogin_WithReturnUrl()
    {
        var context = MakeContext();

        new RequireLoginAttribute().OnActionExecuting(context);

        var redirect = Assert.IsType<RedirectToActionResult>(context.Result);
        Assert.Equal("Login", redirect.ActionName);
        Assert.Equal("Account", redirect.ControllerName);
        Assert.Equal("/Participant/MyResults", redirect.RouteValues!["returnUrl"]);
    }

    [Fact]
    public void Anonymous_Post_HasNoReturnUrl()
    {
        var context = MakeContext(method: "POST");

        new RequireLoginAttribute(Roles.Organiser).OnActionExecuting(context);

        var redirect = Assert.IsType<RedirectToActionResult>(context.Result);
        Assert.Equal("Login", redirect.ActionName);
        Assert.Null(redirect.RouteValues!["returnUrl"]);
    }

    [Fact]
    public void ParticipantOnOrganiserPage_IsSentToAccessDenied()
    {
        var context = MakeContext(7, Roles.Participant);

        new RequireLoginAttribute(Roles.Organiser).OnActionExecuting(context);

        var redirect = Assert.IsType<RedirectToActionResult>(context.Result);
        Assert.Equal("AccessDenied", redirect.ActionName);
    }

    [Fact]
    public void OrganiserOnParticipantPage_IsSentToAccessDenied()
    {
        var context = MakeContext(3, Roles.Organiser);

        new RequireLoginAttribute(Roles.Participant).OnActionExecuting(context);

        var redirect = Assert.IsType<RedirectToActionResult>(context.Result);
        Assert.Equal("AccessDenied", redirect.ActionName);
    }

    [Fact]
    public void OrganiserOnOrganiserPage_IsAllowed()
    {
        var context = MakeContext(3, Roles.Organiser);

        new RequireLoginAttribute(Roles.Organiser).OnActionExecuting(context);

        Assert.Null(context.Result);
    }

    [Fact]
    public void AnyRole_IsAllowedWhenSignedIn()
    {
        var context = MakeContext(7, Roles.Participant);

        new RequireLoginAttribute().OnActionExecuting(context);

        Assert.Null(context.Result);
    }

    [Fact]
    public void GetCurrentUser_ReadsTheSession()
    {
        var context = MakeContext(7, Roles.Participant);

        var user = context.HttpContext.GetCurrentUser();

        Assert.NotNull(user);
        Assert.Equal(7, user!.UserId);
        Assert.True(user.IsParticipant);
        Assert.False(user.IsOrganiser);
        Assert.Equal("T", user.Initials);
    }
}
