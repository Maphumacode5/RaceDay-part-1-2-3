using Microsoft.AspNetCore.Http;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Models.Api;
using RaceDay.Mvc.ViewModels;

namespace RaceDay.Mvc.Tests;

public class ViewHelpersTests
{
    [Theory]
    [InlineData(1, "1st")]
    [InlineData(2, "2nd")]
    [InlineData(3, "3rd")]
    [InlineData(4, "4th")]
    [InlineData(11, "11th")]
    [InlineData(12, "12th")]
    [InlineData(13, "13th")]
    [InlineData(21, "21st")]
    [InlineData(22, "22nd")]
    [InlineData(23, "23rd")]
    [InlineData(47, "47th")]
    [InlineData(101, "101st")]
    [InlineData(111, "111th")]
    [InlineData(112, "112th")]
    public void Ordinal_FormatsCorrectly(int number, string expected)
    {
        Assert.Equal(expected, ViewHelpers.Ordinal(number));
    }

    [Fact]
    public void FormatPosition_ShowsPositionOutOfFinishers()
    {
        Assert.Equal("47th of 312", ViewHelpers.FormatPosition(47, 312));
        Assert.Equal("3rd", ViewHelpers.FormatPosition(3, null));
        Assert.Equal("\u2014", ViewHelpers.FormatPosition(null, 312));
    }

    [Fact]
    public void FormatTime_UsesHoursMinutesSeconds()
    {
        Assert.Equal("02:41:13", ViewHelpers.FormatTime(new TimeSpan(2, 41, 13)));
        Assert.Equal("00:09:05", ViewHelpers.FormatTime(new TimeSpan(0, 9, 5)));
        Assert.Equal("\u2014", ViewHelpers.FormatTime(null));
    }

    [Theory]
    [InlineData("Confirmed", "rd-badge rd-badge-confirmed")]
    [InlineData("Pending", "rd-badge rd-badge-pending")]
    [InlineData("Cancelled", "rd-badge rd-badge-cancelled")]
    [InlineData("Something", "rd-badge")]
    public void StatusClass_ColourCodesEachStatus(string status, string expected)
    {
        Assert.Equal(expected, ViewHelpers.StatusClass(status));
    }

    [Fact]
    public void FormatDistance_TrimsTrailingZeros()
    {
        Assert.Equal("10 km", ViewHelpers.FormatDistance(10m));
        Assert.Equal("21.1 km", ViewHelpers.FormatDistance(21.10m));
        Assert.Equal("42.2 km", ViewHelpers.FormatDistance(42.2m));
    }

    [Fact]
    public void ToInputDateTime_MatchesDatetimeLocalFormat()
    {
        Assert.Equal("2026-11-14T06:30", ViewHelpers.ToInputDateTime(new DateTime(2026, 11, 14, 6, 30, 0)));
    }
}

public class TimeParsingTests
{
    [Theory]
    [InlineData("02:41:13", 2, 41, 13)]
    [InlineData("2:41:13", 2, 41, 13)]
    [InlineData(" 00:45:00 ", 0, 45, 0)]
    public void ValidTimes_AreParsed(string text, int hours, int minutes, int seconds)
    {
        Assert.True(TimeParsing.TryParseFinishTime(text, out var time));
        Assert.Equal(new TimeSpan(hours, minutes, seconds), time);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData(null)]
    [InlineData("abc")]
    [InlineData("02:41")]
    [InlineData("00:00:00")]
    [InlineData("02:61:00")]
    [InlineData("1:2:3")]
    public void InvalidTimes_AreRejected(string? text)
    {
        Assert.False(TimeParsing.TryParseFinishTime(text, out _));
    }
}

public class EventFilteringTests
{
    private static readonly List<EventDto> Events = new()
    {
        new EventDto(1, "Soweto 10K", "Township road race", new DateTime(2026, 12, 5), "Soweto, Gauteng", 10m, "Run", 1, null),
        new EventDto(2, "Charity Walk", null, new DateTime(2026, 11, 20), "Polokwane, Limpopo", 5m, "Walk", 1, null),
        new EventDto(3, "Cycle Classic", "Highveld ride", new DateTime(2026, 12, 1), "Middelburg, Mpumalanga", 94m, "Cycle", 2, null),
        new EventDto(4, "Half Marathon", null, new DateTime(2027, 1, 10), "Cape Town, Western Cape", 21.1m, "Run", 2, null),
        new EventDto(5, "Ultra Trail", null, new DateTime(2027, 2, 14), "Drakensberg, KZN", 56m, "Run", 2, null)
    };

    private static List<int> Ids(EventFilterViewModel filter) =>
        EventFiltering.Apply(Events, filter).Select(e => e.EventId).ToList();

    [Fact]
    public void NoFilter_SortsBySoonestFirst()
    {
        Assert.Equal(new List<int> { 2, 3, 1, 4, 5 }, Ids(new EventFilterViewModel()));
    }

    [Fact]
    public void Search_MatchesNameLocationAndDescription()
    {
        Assert.Equal(new List<int> { 1 }, Ids(new EventFilterViewModel { Search = "soweto" }));
        Assert.Equal(new List<int> { 2 }, Ids(new EventFilterViewModel { Search = "limpopo" }));
        Assert.Equal(new List<int> { 3 }, Ids(new EventFilterViewModel { Search = "highveld" }));
    }

    [Fact]
    public void TypeFilter_KeepsOnlyThatType()
    {
        Assert.Equal(new List<int> { 1, 4, 5 }, Ids(new EventFilterViewModel { Type = "Run" }));
        Assert.Equal(new List<int> { 2 }, Ids(new EventFilterViewModel { Type = "Walk" }));
    }

    [Fact]
    public void TypeAll_KeepsEverything()
    {
        Assert.Equal(5, Ids(new EventFilterViewModel { Type = "All" }).Count);
    }

    [Theory]
    [InlineData("short", new[] { 2 })]
    [InlineData("medium", new[] { 1 })]
    [InlineData("long", new[] { 4 })]
    [InlineData("ultra", new[] { 3, 5 })]
    public void DistanceBands_AreApplied(string band, int[] expected)
    {
        Assert.Equal(expected.ToList(), Ids(new EventFilterViewModel { Distance = band, Sort = "name" })
            .OrderBy(id => id).ToList());
    }

    [Fact]
    public void SortByDistance_OrdersShortestFirst()
    {
        Assert.Equal(new List<int> { 2, 1, 4, 5, 3 }, Ids(new EventFilterViewModel { Sort = "distance" }));
    }

    [Fact]
    public void IsActive_ReflectsChosenFilters()
    {
        Assert.False(new EventFilterViewModel().IsActive);
        Assert.False(new EventFilterViewModel { Type = "All" }.IsActive);
        Assert.True(new EventFilterViewModel { Type = "Run" }.IsActive);
        Assert.True(new EventFilterViewModel { Search = "x" }.IsActive);
    }
}

public class ImageUploadRulesTests
{
    private static FormFile File(long length, string contentType) =>
        new(Stream.Null, 0, length, "image", "upload")
        {
            Headers = new HeaderDictionary(),
            ContentType = contentType
        };

    [Fact]
    public void NoFile_IsNotAnError()
    {
        Assert.Null(ImageUploadRules.Check(null));
        Assert.False(ImageUploadRules.HasFile(null));
    }

    [Fact]
    public void SmallPng_IsAccepted()
    {
        var file = File(1024, "image/png");

        Assert.Null(ImageUploadRules.Check(file));
        Assert.True(ImageUploadRules.HasFile(file));
    }

    [Fact]
    public void FileOverFiveMegabytes_IsRejected()
    {
        Assert.NotNull(ImageUploadRules.Check(File(ImageUploadRules.MaxBytes + 1, "image/png")));
    }

    [Fact]
    public void NonImage_IsRejected()
    {
        Assert.NotNull(ImageUploadRules.Check(File(1024, "application/pdf")));
    }
}
