using System.Net;
using Microsoft.AspNetCore.Http;
using RaceDay.Mvc.Infrastructure;
using RaceDay.Mvc.Services;

namespace RaceDay.Mvc.Tests;

/// <summary>
/// The MVC site depends on one trick: capture the API's session cookie at login and replay it
/// on every later call. These tests pin that behaviour down.
/// </summary>
public class RaceDayApiTests
{
    private const string LoginJson = "{\"message\":\"Login successful.\",\"userId\":5,\"role\":\"Participant\"}";

    private static HttpResponseMessage LoginResponse()
    {
        var response = TestHelpers.Json(HttpStatusCode.OK, LoginJson);
        response.Headers.TryAddWithoutValidation(
            "Set-Cookie", ".RaceDay.Session=abc123; path=/; samesite=lax; httponly");
        return response;
    }

    [Fact]
    public async Task Login_Success_StoresApiSessionCookieInMvcSession()
    {
        var (api, session, _) = TestHelpers.CreateApi(_ => LoginResponse());

        var result = await api.LoginAsync("sipho@example.com", "Password123");

        Assert.True(result.Success);
        Assert.Equal(5, result.Data!.UserId);
        Assert.Equal("Participant", result.Data.Role);
        Assert.Equal(".RaceDay.Session=abc123", session.GetString(SessionKeys.ApiCookie));
    }

    [Fact]
    public async Task LaterCalls_ForwardTheStoredCookie()
    {
        var (api, _, handler) = TestHelpers.CreateApi(request =>
            request.RequestUri!.AbsolutePath.EndsWith("/auth/login")
                ? LoginResponse()
                : TestHelpers.Json(HttpStatusCode.OK, "[]"));

        await api.LoginAsync("sipho@example.com", "Password123");
        await api.GetMyEnrolmentsAsync();

        Assert.Equal(".RaceDay.Session=abc123", handler.LastCookie);
        Assert.Equal("/api/users/me/enrolments", handler.LastPathAndQuery);
    }

    [Fact]
    public async Task BeforeLogin_NoCookieIsSent()
    {
        var (api, _, handler) = TestHelpers.CreateApi(_ => TestHelpers.Json(HttpStatusCode.OK, "[]"));

        await api.GetEventsAsync();

        Assert.Null(handler.LastCookie);
    }

    [Fact]
    public async Task Login_WrongPassword_ReturnsUnauthorizedAndStoresNoCookie()
    {
        var (api, session, _) = TestHelpers.CreateApi(_ =>
            TestHelpers.Json(HttpStatusCode.Unauthorized, "{\"message\":\"Invalid email or password.\"}"));

        var result = await api.LoginAsync("sipho@example.com", "wrong");

        Assert.False(result.Success);
        Assert.True(result.IsUnauthorized);
        Assert.Equal("Invalid email or password.", result.Message);
        Assert.Null(session.GetString(SessionKeys.ApiCookie));
    }

    [Fact]
    public async Task ApiUnreachable_ReturnsFriendlyFailureInsteadOfThrowing()
    {
        var (api, _, _) = TestHelpers.CreateApi(_ => throw new HttpRequestException("connection refused"));

        var result = await api.GetEventsAsync();

        Assert.False(result.Success);
        Assert.True(result.IsUnavailable);
        Assert.DoesNotContain("refused", result.Message);
    }

    [Fact]
    public async Task ApiErrorMessage_IsPassedThroughToTheCaller()
    {
        var (api, _, _) = TestHelpers.CreateApi(_ =>
            TestHelpers.Json(HttpStatusCode.Conflict, "{\"message\":\"Already enrolled in this event.\"}"));

        var result = await api.EnrolAsync(1, 2);

        Assert.False(result.Success);
        Assert.Equal(409, result.StatusCode);
        Assert.Equal("Already enrolled in this event.", result.Message);
    }

    [Fact]
    public async Task ValidationProblemDetails_AreFlattenedIntoOneMessage()
    {
        var json = "{\"title\":\"One or more validation errors occurred.\",\"errors\":{\"Name\":[\"The Name field is required.\"]}}";
        var (api, _, _) = TestHelpers.CreateApi(_ => TestHelpers.Json(HttpStatusCode.BadRequest, json));

        var result = await api.CreateCategoryAsync(1, "", null);

        Assert.False(result.Success);
        Assert.Contains("The Name field is required.", result.Message);
    }

    [Fact]
    public async Task GetEvents_BuildsQueryString()
    {
        var (api, _, handler) = TestHelpers.CreateApi(_ => TestHelpers.Json(HttpStatusCode.OK, "[]"));

        await api.GetEventsAsync("Run", new DateTime(2026, 11, 8));

        Assert.Equal("/api/events?eventType=Run&from=2026-11-08", handler.LastPathAndQuery);
    }

    [Fact]
    public async Task GetEvents_AllType_IsNotSentToTheApi()
    {
        var (api, _, handler) = TestHelpers.CreateApi(_ => TestHelpers.Json(HttpStatusCode.OK, "[]"));

        await api.GetEventsAsync("All", null);

        Assert.Equal("/api/events", handler.LastPathAndQuery);
    }

    [Fact]
    public async Task GetEvents_DeserialisesCamelCaseJson()
    {
        var json = "[{\"eventId\":7,\"name\":\"Soweto 10K\",\"description\":null,\"eventDate\":\"2026-12-01T06:00:00\"," +
                   "\"location\":\"Soweto\",\"distanceKm\":10.0,\"eventType\":\"Run\",\"organiserId\":1,\"bannerImageUrl\":null}]";
        var (api, _, _) = TestHelpers.CreateApi(_ => TestHelpers.Json(HttpStatusCode.OK, json));

        var result = await api.GetEventsAsync();

        var item = Assert.Single(result.Data!);
        Assert.Equal(7, item.EventId);
        Assert.Equal("Soweto 10K", item.Name);
        Assert.Equal(10m, item.DistanceKm);
        Assert.Equal("Run", item.EventType);
    }

    [Fact]
    public async Task CaptureResult_SendsFinishTimeAsHoursMinutesSeconds()
    {
        var (api, _, handler) = TestHelpers.CreateApi(_ =>
            TestHelpers.Json(HttpStatusCode.Created, "{\"resultId\":1}"));

        var result = await api.CaptureResultAsync(9, new TimeSpan(2, 41, 13), 47, 312);

        Assert.True(result.Success);
        Assert.Equal("POST", handler.LastMethod);
        Assert.Equal("/api/enrolments/9/results", handler.LastPathAndQuery);
        Assert.Contains("\"finishTime\":\"02:41:13\"", handler.LastBody);
        Assert.Contains("\"finishPosition\":47", handler.LastBody);
        Assert.Contains("\"totalFinishers\":312", handler.LastBody);
    }

    [Fact]
    public async Task Delete_NoContent_IsSuccess()
    {
        var (api, _, handler) = TestHelpers.CreateApi(_ => new HttpResponseMessage(HttpStatusCode.NoContent));

        var result = await api.DeleteEventAsync(3);

        Assert.True(result.Success);
        Assert.Equal("DELETE", handler.LastMethod);
        Assert.Equal("/api/events/3", handler.LastPathAndQuery);
    }

    [Fact]
    public void ExtractSessionCookie_FindsTheRaceDayCookieAmongOthers()
    {
        var headers = new[]
        {
            "other=1; path=/",
            ".RaceDay.Session=XYZ; path=/; samesite=lax; httponly"
        };

        Assert.Equal(".RaceDay.Session=XYZ", RaceDayApi.ExtractSessionCookie(headers));
    }

    [Fact]
    public void ExtractSessionCookie_NoMatch_ReturnsNull()
    {
        Assert.Null(RaceDayApi.ExtractSessionCookie(new[] { "other=1; path=/" }));
    }
}
